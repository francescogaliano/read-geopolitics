// node fotogrammi.mjs spec.json t1 t2 ... -> salva /tmp/rf_<t>.jpg e controlla le regole della regia (senza voce, tempi stimati)
import fs from 'fs';const {chromium}=await import([process.env.PW_MODULE,process.env.HOME+'/igkit/node_modules/playwright/index.mjs','/opt/npm-tools/node_modules/playwright/index.mjs'].filter(Boolean).find(f=>fs.existsSync(f)));
const spec=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));const b=await chromium.launch();const p=await b.newPage({viewport:{width:1080,height:1920}});const errs=[];p.on('pageerror',e=>errs.push(String(e)));
await p.goto('file://'+process.cwd()+'/motore.html');await p.evaluate(async()=>{for(const f of ['600 40px RS','400 30px RN','600 30px RN','500 24px RM'])await document.fonts.load(f)});
await p.evaluate(s=>load(s),spec);const T=await p.evaluate(()=>setup(stima(),1.6));const chk=await p.evaluate(s=>window.regiaCheck?regiaCheck(s):['regiaCheck assente'],spec);
const ts=process.argv.slice(3).map(Number);const out=[];for(const t of ts){await p.evaluate(t=>draw(t),t);const f='/tmp/rf_'+t+'.jpg';await p.screenshot({path:f,type:'jpeg',quality:80});out.push(f)}
await b.close();console.log(JSON.stringify({T,regole:chk,errori:errs,fotogrammi:out}))
