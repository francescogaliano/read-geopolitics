# voce.py sb.json (campo frasi_voce) — UNA sola registrazione (voce Orus) per tutto il video, poi i tempi di ogni frase dalle pause.
# Scrive voce.wav e tempi.json {"start":[...],"dur":[...],"ok":bool}
import sys,os,json,re,subprocess
HERE=os.path.dirname(os.path.abspath(__file__));SB=json.load(open(sys.argv[1],encoding="utf-8"));SB=SB if isinstance(SB,dict) else {"frasi_voce":SB};F=SB["frasi_voce"];N=len(F)
VOICE=SB.get("voce") or os.environ.get("RG_VOICE","Orus");MODEL=os.environ.get("RG_POD_MODEL","gemini-2.5-pro-tts")
PROMPT=("Leggi in italiano come il narratore di un video divulgativo per i social: voce calda e chiara, ritmo naturale e scorrevole, "
        "mai affrettato, con il tono di chi spiega una cosa importante a un amico. Metti in rilievo i numeri. "
        "Tra un paragrafo e l'altro fai SEMPRE una pausa netta di circa un secondo. Leggi solo il testo, parola per parola, senza aggiungere né togliere nulla.")
def allinea(S,lead,dur,F):
    # scelta delle N-1 pause con programmazione dinamica: ogni frase deve durare in proporzione alla sua lunghezza
    # (velocita' di lettura simile per tutte) e si preferiscono le pause lunghe. Le sole pause piu' lunghe sbagliano
    # quando la voce fa una pausa a meta' frase o "mangia" quella tra due frasi.
    import math
    N=len(F);L=[max(len(x),1) for x in F];M=len(S);cps=sum(L)/max(dur-lead-sum(b-a for a,b in S)*0.5,1)
    def seg(t0,t1,i):
        d=max(t1-t0,0.05);return math.log(d*cps/L[i])**2
    INF=float("inf");best=[[INF]*(M+1) for _ in range(N)];prev=[[-1]*(M+1) for _ in range(N)]
    for j in range(M):
        best[0][j]=seg(lead,S[j][0],0)-0.6*(S[j][1]-S[j][0])
    for i in range(1,N-1):
        for j in range(i,M):
            for k in range(i-1,j):
                if best[i-1][k]==INF: continue
                v=best[i-1][k]+seg(S[k][1],S[j][0],i)-0.6*(S[j][1]-S[j][0])
                if v<best[i][j]: best[i][j]=v;prev[i][j]=k
    if N==1: big=[]
    else:
        fin=[(best[N-2][j]+seg(S[j][1],dur,N-1),j) for j in range(M) if best[N-2][j]<INF]
        j=min(fin)[1];idx=[j]
        for i in range(N-2,0,-1): j=prev[i][j];idx.append(j)
        big=[S[k] for k in sorted(idx)]
    return [lead]+[b for a,b in big],[a for a,b in big]+[dur]
PROMPT=SB.get("stile_voce") or PROMPT
REG=SB.get("regia") or []
if REG and len(REG)==N:
    PROMPT+="\n\nNOTE DI REGIA, una per paragrafo, nello stesso ordine (NON vanno lette):\n"+"\n".join(f"{i+1}. «{F[i][:40]}…»: {r}" for i,r in enumerate(REG))+"\n\nTESTO DA LEGGERE:"
txt="\n\n".join(F);open("voce_testo.txt","w",encoding="utf-8").write(txt)
MOTORE="gemini"
if SB.get("motore")=="elevenlabs" and not os.path.exists("voce_raw.wav"):
    r=subprocess.run(["python3",os.path.join(HERE,"el_voce.py"),sys.argv[1]],capture_output=True,text=True)
    if r.returncode==0 and os.path.exists("voce_raw.wav"): MOTORE="elevenlabs"
    else: print("ElevenLabs non riuscito, uso Gemini: "+(r.stdout+r.stderr)[-300:],file=sys.stderr)
if not os.path.exists("voce_raw.wav"):
    r=subprocess.run(["python3",os.path.join(HERE,"gem_vertex.py"),VOICE,MODEL,"voce_testo.txt","voce_raw.wav",PROMPT],capture_output=True,text=True)
    if r.returncode or not os.path.exists("voce_raw.wav"): sys.exit("voce non riuscita: "+(r.stdout+r.stderr)[-300:])
subprocess.run(["ffmpeg","-y","-v","error","-i","voce_raw.wav","-ar","44100","-ac","1","voce.wav"],check=True)
dur=float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0","voce.wav"],capture_output=True,text=True).stdout)
e=subprocess.run(["ffmpeg","-v","info","-i","voce.wav","-af","silencedetect=noise=-38dB:d=0.32","-f","null","-"],capture_output=True,text=True).stderr
ss=[float(x) for x in re.findall(r"silence_start: ([\d.]+)",e)];se=[float(x) for x in re.findall(r"silence_end: ([\d.]+)",e)]
S=[(a,b) for a,b in zip(ss,se) if a>0.05 and b<dur-0.05]
lead=se[0] if ss and ss[0]<=0.05 and se else 0.0
ok=len(S)>=N-1
if ok:
    starts,ends=allinea(S,lead,dur,F)
else:  # ripiego: tempi proporzionali alla lunghezza delle frasi
    L=[len(x) for x in F];tot=sum(L);starts=[];ends=[];t=lead
    for l in L: d=(dur-lead)*l/tot;starts.append(t);ends.append(t+d*0.92);t+=d
if MOTORE=="elevenlabs" and os.path.exists("el_align.json"):
    A=json.load(open("el_align.json"))
    if len(A["start"])==N: starts=A["start"];ends=A["end"];ok=True
json.dump({"start":[round(x,3) for x in starts],"dur":[round(b-a,3) for a,b in zip(starts,ends)],"totale":round(dur,2),"ok":ok,"pause_trovate":len(S)},open("durate.json","w"))
print(json.dumps({"totale":round(dur,1),"frasi":N,"pause_trovate":len(S),"allineamento":("timestamp ElevenLabs" if MOTORE=="elevenlabs" and os.path.exists("el_align.json") else ("pause" if ok else "proporzionale")),"motore":MOTORE}))
