# bozza.py video.mp4 DIDASCALIA_FILE DATA [FORMATO] [REQ_ID] — manda il reel al pannello come bozza da approvare
# FORMATO predefinito "punti"; per le richieste dal pannello usa "icon-<id richiesta>" e passa REQ_ID (così la bozza resta legata alla richiesta).
import sys,os,json,base64,urllib.request,urllib.error
v,cf,date=sys.argv[1:4];fmt=(sys.argv[4] if len(sys.argv)>4 else "punti");rq=(sys.argv[5] if len(sys.argv)>5 else "")
api=os.environ["RG_API"].rstrip("/");tok=os.environ["RG_TOKEN"]
body={"format":fmt,"date":date,"type":"reel","caption":open(cf,encoding="utf-8").read().strip(),"video_b64":base64.b64encode(open(v,"rb").read()).decode(),"force":True}
if rq: body["req_id"]=rq
req=urllib.request.Request(api+"/v1/ig/drafts",data=json.dumps(body).encode(),headers={"content-type":"application/json","authorization":"Bearer "+tok,"user-agent":"rg-punti/1.0 (+https://www.readgeopolitics.com)","accept":"application/json"},method="POST")
try:
    r=json.load(urllib.request.urlopen(req,timeout=180));print(json.dumps({k:r.get(k) for k in ("ok","id","status","mode","video_url")}))
except urllib.error.HTTPError as e: print("errore",e.code,e.read().decode()[:400]);sys.exit(1)
