# bozza.py video.mp4 DIDASCALIA_FILE DATA — manda il reel al pannello come bozza da approvare (formato «punti»)
import sys,os,json,base64,urllib.request
v,cf,date=sys.argv[1:4];api=os.environ["RG_API"].rstrip("/");tok=os.environ["RG_TOKEN"]
body={"format":"punti","date":date,"type":"reel","caption":open(cf,encoding="utf-8").read().strip(),"video_b64":base64.b64encode(open(v,"rb").read()).decode(),"force":True}
req=urllib.request.Request(api+"/v1/ig/drafts",data=json.dumps(body).encode(),headers={"content-type":"application/json","authorization":"Bearer "+tok,"user-agent":"rg-punti/1.0 (+https://www.readgeopolitics.com)","accept":"application/json"},method="POST")
try:
    r=json.load(urllib.request.urlopen(req,timeout=180));print(json.dumps({k:r.get(k) for k in ("ok","id","status","mode","video_url")}))
except urllib.error.HTTPError as e: print("errore",e.code,e.read().decode()[:400]);sys.exit(1)
