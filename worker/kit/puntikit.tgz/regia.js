/* regia.js — scena «regia»: mappa viva, attori e verbi animati (libreria v1, 31/10/2026).
   Si carica dopo azioni.js e usa gli aiuti del motore (c, txt, tw, wrap, E, EB, EI, cl, ph, at, COL, col, GEOF, GBY, forma, persona, icon, rr).
   Regole del taccuino (37-40): ogni elemento ha un'etichetta o una voce di legenda; un significato = un colore e un tratto per tutto il video;
   etichette accanto alla cosa, dentro il riquadro, mai sovrapposte; ogni frase è un'azione visibile.

   Specifica: {"tipo":"regia", "mappa":{...} | assente (palco senza mappa), "elementi":[...], "legenda":true}
   Tempi: ogni elemento ha "f" = frase della scena in cui agisce (0 = prima frase della scena), "dt" = secondi dopo l'inizio di quella frase,
   "fino" = frase dopo la quale sparisce (facoltativo).
   mappa: {"camera":[{"f":0,"centro":[lon,lat],"zoom":2000},...], "paesi":{"UKR":{"stile":"evidenzia"},"BLR":{"stile":"accendi","f":3}}, "nomi":[{"dove":[lon,lat],"testo":"RUSSIA","f":0,"fino":1}]}
   palco (senza mappa): le posizioni sono [x,y] tra 0 e 1 dentro il riquadro.
   Elementi:
     linea   {stile: fiume|strada|rotta|freccia|confine, punti:[...], etichetta, legenda:true/false, durata}
     punto   {dove, etichetta, nota, colore}
     anello  {dove, colore, per:"etichetta del punto"}               verbo: si chiude
     luce    {dove, raggio, attenua:true, per:"…"}                    verbo: si accende (il resto si abbassa)
     attori  {icona: persona|anziano|bambino|folla|<icona Tabler>, n, verbo, dove|lungo, etichetta, size, colore}
             verbi: appare, entra, percorre, parte, sale, scende, spinge, si_ferma, cresce, cala, sparisce
     contatore {n, etichetta, colore}                                  verbo: si riempie, una casella alla volta
*/
(function(){
const STILI={fiume:{c:"#5fa6e8",w:7,dash:null},strada:{c:"#4a6a94",w:5,dash:[16,14]},rotta:{c:COL.oro,w:7,dash:[22,14],mov:true},freccia:{c:COL.oro,w:9,dash:null,punta:true},confine:{c:"#b9c4cf",w:3,dash:[6,8]}};
const CAMC={};
function camAt(t,S,M){const K=M.camera||[];if(!K.length)return null;const ts=K.map(k=>at(S.i0+(k.f||0),k.dt||0));let i=0;while(i<K.length-2&&t>ts[i+1])i++;
  const a=K[i],b=K[Math.min(i+1,K.length-1)];const u=K.length<2?1:EI(cl((t-ts[i])/Math.max(0.01,(ts[i+1]-ts[i])||1)));
  const lz=Math.exp(Math.log(a.zoom)+(Math.log(b.zoom)-Math.log(a.zoom))*u);return {c:[a.centro[0]+(b.centro[0]-a.centro[0])*u,a.centro[1]+(b.centro[1]-a.centro[1])*u],z:lz}}
const tIn=(t,S,e,d0,d1)=>ph(t,S.i0+(e.f||0),(e.dt||0.1)+(d0||0),(e.dt||0.1)+(d1==null?0.6:d1));
/* «fino»: l'elemento resta per tutta quella frase e sfuma appena prima che inizi la successiva */
const vis=(t,S,e)=>{const a=tIn(t,S,e,0,0.4);const z=e.fino!=null?1-ph(t,S.i0+e.fino+1,-0.45,-0.05):1;return Math.min(a,z)};
function lenOf(q){let L=0;const s=[];for(let i=1;i<q.length;i++){const d=Math.hypot(q[i][0]-q[i-1][0],q[i][1]-q[i-1][1]);s.push(d);L+=d}return {L,s}}
function along(q,u){const {L,s}=lenOf(q);let r=L*cl(u);for(let i=1;i<q.length;i++){if(r<=s[i-1]){const f=s[i-1]?r/s[i-1]:0;return [q[i-1][0]+(q[i][0]-q[i-1][0])*f,q[i-1][1]+(q[i][1]-q[i-1][1])*f]}r-=s[i-1]}return q[q.length-1]}
function stroke(q,u,st,t){const {L,s}=lenOf(q);let r=L*cl(u);c.save();c.strokeStyle=st.c;c.lineWidth=st.w;c.lineCap="round";c.lineJoin="round";if(st.dash){c.setLineDash(st.dash);if(st.mov)c.lineDashOffset=-t*40}
  c.beginPath();c.moveTo(q[0][0],q[0][1]);let end=q[0],prev=q[0];for(let i=1;i<q.length&&r>0;i++){const f=Math.min(1,r/(s[i-1]||1));prev=q[i-1];end=[q[i-1][0]+(q[i][0]-q[i-1][0])*f,q[i-1][1]+(q[i][1]-q[i-1][1])*f];c.lineTo(end[0],end[1]);r-=s[i-1]}c.stroke();c.setLineDash([]);
  if(st.punta&&u>0.05){const ang=Math.atan2(end[1]-prev[1],end[0]-prev[0]);c.fillStyle=st.c;c.beginPath();c.moveTo(end[0]+Math.cos(ang)*26,end[1]+Math.sin(ang)*26);c.lineTo(end[0]+Math.cos(ang+2.5)*24,end[1]+Math.sin(ang+2.5)*24);c.lineTo(end[0]+Math.cos(ang-2.5)*24,end[1]+Math.sin(ang-2.5)*24);c.fill()}
  c.restore();return end}
/* etichetta che resta dentro il riquadro e non si sovrappone alle altre già messe in questo fotogramma */
let _LQ=null;function etichetta(s,x,y,colr,box,PLACED,font,gap){if(!s)return;if(_LQ){_LQ.push([s,x,y,colr,box,PLACED,font,gap,c.globalAlpha]);return}const f=font||"500 30px RM";const w=tw(s,f),h=34,g=gap||22;let cand=[[x+g,y-12],[x+g,y+30],[x-g-w,y-12],[x-g-w,y+30],[x-w/2,y-g-12],[x-w/2,y+g+34]];
  /* dopo le posizioni preferite, cerca a spirale un posto libero vicino (fino a 340 px) */
  for(let d=g+40;d<=340;d+=30)for(let k=0;k<12;k++){const an=k*Math.PI/6;cand.push([x+Math.cos(an)*d-(Math.cos(an)<0?w:0),y+Math.sin(an)*d+12])}
  for(const [cx,cy] of cand){const r={x0:cx-6,y0:cy-h,x1:cx+w+6,y1:cy+10};if(r.x0<box.x0+16||r.x1>box.x1-16||r.y0<box.y0+16||r.y1>box.y1-16)continue;if(PLACED.some(p=>!(r.x1<p.x0||r.x0>p.x1||r.y1<p.y0||r.y0>p.y1)))continue;PLACED.push(r);
    if(Math.hypot(cx+w/2-x,cy-12-y)>g+60){c.save();c.strokeStyle=colr;c.globalAlpha*=0.6;c.lineWidth=2;c.beginPath();c.moveTo(x,y);c.lineTo(cx+(cx>x?-4:w+4),cy-12);c.stroke();c.restore()}
    txt(s,cx,cy,f,colr);return}
  const cx=Math.max(box.x0+16,Math.min(box.x1-16-w,x+22)),cy=Math.max(box.y0+16+h,Math.min(box.y1-16,y-12));PLACED.push({x0:cx,y0:cy-h,x1:cx+w,y1:cy+10});txt(s,cx,cy,f,colr)}
let _PL=null;function attore(k,x,y,size,colr,a){if(a<=0)return;const isP=["persona","uomo","donna","anziano","bambino","folla","soldato","medico","lavoratore","delegato"].includes(k);if(_PL)_PL.push(isP?{x0:x-size*0.3,y0:y-size,x1:x+size*0.3,y1:y}:{x0:x-size/2,y0:y-size/2,x1:x+size/2,y1:y+size/2});const PT=["persona","uomo","donna","anziano","bambino","folla","soldato","medico","lavoratore","delegato"];if(PT.includes(k)&&typeof persona==="function")persona(k==="persona"?"uomo":k,x,y,size,colr,a);else icon(k,x,y,size,colr,null,a)}

SC.regia=(t,S)=>{const p=S.p;const box={x0:50,y0:S.top+20,x1:1030,y1:p.basso||1730};const EL=p.elementi||[];const PLACED=[];_PL=PLACED;_LQ=[];
  const a0=E(ph(t,S.i0,-0.2,0.4));if(a0<=0)return;c.save();c.globalAlpha*=a0;
  rr(box.x0,box.y0,box.x1-box.x0,box.y1-box.y0,36);c.fillStyle="#0c1322";c.fill();c.save();rr(box.x0,box.y0,box.x1-box.x0,box.y1-box.y0,36);c.clip();
  let P;const M=p.mappa;
  if(M){const cm=camAt(t,S,M)||{c:[12,45],z:900};const pr=d3.geoMercator().center(cm.c).scale(cm.z).translate([(box.x0+box.x1)/2,(box.y0+box.y1)/2]);const path=d3.geoPath(pr,c);P=pt=>pr(pt);
    const PS=M.paesi||{};
    for(const f of GEOF){const st=PS[f.id];let fill="#152033",sk="#2a3b55";
      if(st){const k=st.f!=null?tIn(t,S,st,0,0.8):1;if(st.stile==="evidenzia"){fill=mix("#152033","#1c2c45",k);sk=mix("#2a3b55","#4a6a94",k)}if(st.stile==="accendi"){fill=mix("#152033","#2b4466",k);sk=mix("#2a3b55",COL.azz,k)}if(st.stile==="attenua"){fill=mix("#152033","#10182a",k)}if(st.stile==="rosso"){fill=mix("#152033","#3a1f26",k);sk=mix("#2a3b55","#e5786d",k)}}
      c.beginPath();path(f);c.fillStyle=fill;c.fill();c.strokeStyle=sk;c.lineWidth=1.5;c.stroke()}
    for(const n of (M.nomi||[])){const a=vis(t,S,n);if(a<=0)continue;const q=P(n.dove);c.save();c.globalAlpha*=a;txt(n.testo,q[0],q[1],"500 32px RM",n.colore?col(n.colore):COL.grigio,"center");c.restore();PLACED.push({x0:q[0]-tw(n.testo,"500 32px RM")/2,y0:q[1]-34,x1:q[0]+tw(n.testo,"500 32px RM")/2,y1:q[1]+8})}
  }else{const w=box.x1-box.x0,h=box.y1-box.y0;P=pt=>[box.x0+pt[0]*w,box.y0+pt[1]*h]}
  /* luce: abbassa tutto il resto, poi la luce (sotto gli altri elementi) */
  for(const e of EL.filter(e=>e.tipo==="luce")){const a=vis(t,S,e);if(a<=0)continue;const q=P(e.dove);const R=(e.raggio||260)*tIn(t,S,e,0,1.0);
    if(e.attenua!==false){c.save();c.fillStyle="rgba(8,12,22,"+(0.55*a)+")";c.fillRect(box.x0,box.y0,box.x1-box.x0,box.y1-box.y0);c.restore()}
    const g=c.createRadialGradient(q[0],q[1],8,q[0],q[1],Math.max(10,R));g.addColorStop(0,"rgba(232,163,61,"+(0.55*a)+")");g.addColorStop(1,"rgba(232,163,61,0)");c.fillStyle=g;c.beginPath();c.arc(q[0],q[1],Math.max(10,R),0,7);c.fill()}
  const LEG=[];
  for(const e of EL){const a=vis(t,S,e);if(e.tipo==="luce")continue;
    if(e.tipo==="linea"){const st=STILI[e.stile]||STILI.rotta;if(e.legenda!==false&&e.etichetta&&(e.stile==="rotta"||e.stile==="strada"||e.stile==="freccia"||e.legenda))LEG.push({st,txt:e.etichetta,a});
      if(a<=0)continue;const q=e.punti.map(P);c.save();c.globalAlpha*=a;forma({id:"linea:"+(e.etichetta||""),tipo:"linea",box},()=>stroke(q,tIn(t,S,e,0,e.durata||1.6),st,t));
      if(e.etichetta&&!(LEG.length&&LEG[LEG.length-1].txt===e.etichetta)){const m=along(q,e.etichetta_a!=null?e.etichetta_a:0.55);etichetta(e.etichetta,m[0],m[1],st.c,box,PLACED)}c.restore();continue}
    if(a<=0)continue;c.save();c.globalAlpha*=a;
    if(e.tipo==="punto"){const q=P(e.dove);const cc=col(e.colore||"bianco");c.fillStyle=cc;c.beginPath();c.arc(q[0],q[1],14,0,7);c.fill();const ring=EL.some(z=>z.tipo==="anello"&&z.per===e.etichetta&&vis(t,S,z)>0);const g=ring?(EL.find(z=>z.tipo==="anello"&&z.per===e.etichetta).raggio||70)+16:22;PLACED.push({x0:q[0]-g,y0:q[1]-g,x1:q[0]+g,y1:q[1]+g});if(e.etichetta)etichetta(e.etichetta,q[0],q[1]-6,COL.bianco,box,PLACED,null,g);if(e.nota)etichetta(e.nota,q[0],q[1]+34,col(e.colore_nota||"#e5786d"),box,PLACED,null,g)}
    if(e.tipo==="anello"){const q=P(e.dove);const u=tIn(t,S,e,0,0.9);c.strokeStyle=col(e.colore||"#e5786d");c.lineWidth=8;c.beginPath();c.arc(q[0],q[1],e.raggio||70,-Math.PI/2,-Math.PI/2+Math.PI*2*u);c.stroke()}
    if(e.tipo==="contatore"){const n=e.n||3,sz=Math.min(90,820/n-14),gap=14,W=n*sz+(n-1)*gap,x0=540-W/2,y=box.y1-sz-200;const cc=col(e.colore||"oro");
      for(let i=0;i<n;i++){const k=tIn(t,S,e,i*0.25,i*0.25+0.3);c.save();c.strokeStyle=cc;c.lineWidth=3;c.strokeRect(x0+i*(sz+gap),y,sz,sz);c.globalAlpha*=0.4*k;c.fillStyle=cc;c.fillRect(x0+i*(sz+gap),y,sz,sz);c.restore()}
      if(e.etichetta)txt(e.etichetta,540,y+sz+52,"500 30px RM",cc,"center")}
    if(e.tipo==="attori"){const n=e.n||1,sz=e.size||80,cc=col(e.colore||"bianco"),k=e.icona||"persona",v=e.verbo||"appare";let lab=null;
      if(e.lungo){const q=e.lungo.map(P);const u=tIn(t,S,e,0,e.durata||1.8);
        if(e.verbo!=="si_ferma"||true){for(let j=0;j<n;j++){let uu=cl(u-j*(0.6/Math.max(1,n)));if(v==="si_ferma")uu=Math.min(uu,e.stop||0.7);if(uu<=0)continue;const pp=along(q,uu);attore(k,pp[0],pp[1]-(["persona","uomo","donna","anziano","bambino","folla","soldato","medico","lavoratore","delegato"].includes(k)?0:sz*0.4),sz,cc,1);if(j===0)lab=pp}}
        if(v==="si_ferma"){const sp=along(q,e.stop||0.7);const b=tIn(t,S,e,0.2,0.6);c.save();c.strokeStyle=COL.oro;c.lineWidth=8;c.globalAlpha*=b;c.beginPath();c.moveTo(sp[0]+40,sp[1]-70);c.lineTo(sp[0]+40,sp[1]+40);c.stroke();c.restore()}
      }else{const q=P(e.dove);const spread=e.spaziatura||sz*0.9;
        for(let j=0;j<n;j++){const x=q[0]+(j-(n-1)/2)*spread;let y=q[1],aa=1,ss=sz;const u=tIn(t,S,e,j*0.12,j*0.12+0.7);
          if(v==="appare"){aa=u;ss=sz*(0.6+0.4*EB(u))}
          if(v==="parte"){y-=u*(e.di||70);aa=1-u}
          if(v==="sale"){y-=u*(e.di||160)}
          if(v==="scende"){y+=u*(e.di||160)}
          if(v==="cresce"){ss=sz*(1+u*((e.fattore||1.8)-1))}
          if(v==="cala"){ss=sz*(1-u*(1-(e.fattore||0.5)))}
          if(v==="sparisce"){aa=1-u}
          if(v==="spinge"){const d=e.verso||[1,0];const push=EI(u)*(e.di||120);attore(k,x+d[0]*push*0.5,y+d[1]*push*0.5,ss,cc,aa);if(e.bersaglio&&j===0){const b=EL.find(z=>z.id===e.bersaglio);if(b)b._off=[d[0]*push,d[1]*push]}continue}
          attore(k,x,y,ss,cc,aa)}lab=[q[0],q[1]-sz*0.9]}
      if(e.etichetta&&lab)etichetta(e.etichetta,lab[0],lab[1]-sz*0.3,col(e.colore_etichetta||e.colore||"azz"),box,PLACED)}
    if(e.tipo==="oggetto"){const q=P(e.dove);const off=e._off||[0,0];const sz=e.size||140;icon(e.icona,q[0]+off[0],q[1]+off[1],sz,col(e.colore||"azz"),null,1);if(e.etichetta)etichetta(e.etichetta,q[0]+off[0]+sz*0.4,q[1]+off[1],col(e.colore||"azz"),box,PLACED)}
    c.restore()}
  /* etichette per ultime: così evitano tutte le figure già disegnate */
  const Q=_LQ;_LQ=null;for(const a of Q){c.save();c.globalAlpha=a[8];etichetta(...a.slice(0,8));c.restore()}
  /* legenda in basso: un tratto = un significato */
  let ly=box.y1-40;for(const L of LEG){if(L.a<=0)continue;c.save();c.globalAlpha*=L.a;c.strokeStyle=L.st.c;c.lineWidth=L.st.w;if(L.st.dash)c.setLineDash(L.st.dash);c.beginPath();c.moveTo(box.x0+30,ly-10);c.lineTo(box.x0+130,ly-10);c.stroke();c.setLineDash([]);txt(L.txt,box.x0+150,ly,"500 30px RM",L.st.c);c.restore();ly-=50}
  if(p.nota&&t>=at(S.i0+(p.nota_f!=null?p.nota_f:S.n-1),0.2)){txt(p.nota,box.x0+30,box.y1-16-(LEG.length?LEG.length*50:0),"500 24px RM",COL.muto)}
  c.restore();c.restore()};

/* controllo delle regole 37-40 sulla specifica (lo usa rg.mjs check) */
window.regiaCheck=function(spec){const err=[];(spec.frasi||[]).forEach((f,i)=>{const sc=f.scena;if(!sc||sc.tipo!=="regia")return;const lab=new Set();
  (sc.elementi||[]).forEach((e,j)=>{const w="frase "+i+", elemento "+j+" ("+e.tipo+")";
    if(["linea","attori","contatore","oggetto","punto"].includes(e.tipo)&&!e.etichetta)err.push(w+": manca l'etichetta (regola 37: ogni cosa in scena dice cos'è)");
    if((e.tipo==="anello"||e.tipo==="luce")&&!e.per)err.push(w+": serve «per» con l'etichetta del punto a cui si riferisce");
    if(e.etichetta)lab.add(e.etichetta);
    if(e.tipo==="linea"&&!STILI[e.stile])err.push(w+": stile sconosciuto «"+e.stile+"»");
    if(e.tipo==="linea"&&(!Array.isArray(e.punti)||e.punti.length<2))err.push(w+": servono almeno due punti");
    if(e.tipo==="attori"&&!e.dove&&!e.lungo)err.push(w+": serve «dove» o «lungo»")});
  (sc.elementi||[]).filter(e=>e.tipo==="anello"||e.tipo==="luce").forEach(e=>{if(e.per&&!lab.has(e.per))err.push("frase "+i+": «per» non corrisponde a nessuna etichetta: "+e.per)});
  const st={};(sc.elementi||[]).filter(e=>e.tipo==="linea"&&e.etichetta).forEach(e=>{if(st[e.etichetta]&&st[e.etichetta]!==e.stile)err.push("frase "+i+": «"+e.etichetta+"» compare con due stili diversi (regola 38)");st[e.etichetta]=e.stile})});
  return err};
})();
