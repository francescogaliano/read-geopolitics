// cartello.mjs out.png TITOLO VOCE DESCRIZIONE — cartello 1080x1920 nello stile RG per i provini di voce
import fs from 'fs';import os from 'os';import path from 'path';
const cand=[process.env.PW_MODULE,os.homedir()+'/igkit/node_modules/playwright/index.mjs','/opt/npm-tools/node_modules/playwright/index.mjs'].filter(Boolean);
const {chromium}=await import(cand.find(f=>fs.existsSync(f)));
const [out,tit,voce,desc]=process.argv.slice(2);const D=path.dirname(new URL(import.meta.url).pathname);
const f=n=>'data:font/woff2;base64,'+fs.readFileSync(D+'/fonts/'+n).toString('base64');
const html=`<html><head><style>@font-face{font-family:RS;src:url(${f('ibm-plex-serif-latin-600-normal.woff2')})}@font-face{font-family:RM;src:url(${f('ibm-plex-mono-latin-500-normal.woff2')})}
body{margin:0;width:1080px;height:1920px;background:radial-gradient(circle at 50% 45%,#15233a,#0a0f18 70%);color:#EEF2F6;display:flex;flex-direction:column;align-items:center;justify-content:center}
.k{font:500 34px RM;letter-spacing:6px;color:#E8A33D}.v{font:600 150px RS;margin:30px 0 10px}.d{font:500 40px RM;color:#B9C4CF;text-align:center;max-width:860px}</style></head>
<body><div class="k">${tit}</div><div class="v">${voce}</div><div class="d">${desc}</div></body></html>`;
const b=await chromium.launch();const p=await b.newPage({viewport:{width:1080,height:1920}});await p.setContent(html);await p.evaluate(()=>document.fonts.ready);await p.screenshot({path:out});await b.close();
