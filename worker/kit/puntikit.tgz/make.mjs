// make.mjs sb.json out.mp4 [durate.json]
// Se sb.json ha "spec": rende con motore.html (scene della libreria) sui tempi di durate.json (una voce per frase con voce),
// altrimenti si comporta come prima (video.html + B). Mix: musica 0.13 sotto la voce, loudnorm -14 LUFS, dissolvenza finale.
import fs from 'fs';import {execSync} from 'child_process';import os from 'os';
const cand=[process.env.PW_MODULE,os.homedir()+'/igkit/node_modules/playwright/index.mjs','/home/claude/kit/node_modules/playwright/index.mjs','/opt/npm-tools/node_modules/playwright/index.mjs'].filter(Boolean);
const {chromium}=await import(cand.find(f=>fs.existsSync(f)));
const [sbf,out,tf]=process.argv.slice(2);const SB=(()=>{try{return JSON.parse(fs.readFileSync(sbf,'utf8'))}catch(e){return {}}})();
const SPEC=SB.spec&&typeof SB.spec==='object'?SB.spec:null;const H=SPEC?'motore.html':(SB.html||'video.html');const LEAD=1.6;
let tm=tf&&fs.existsSync(tf)?JSON.parse(fs.readFileSync(tf,'utf8')):null;
if(tm&&SPEC){/* tempi per frase della voce -> tempi per frase della spec (le frasi mute prendono lo spazio prima della frase con voce seguente) */
  const F=SPEC.frasi;const voc=F.map(f=>((f.voce??f.t)||'').trim().length>0&&!f.muta);const nv=voc.filter(Boolean).length;
  if(tm.start.length!==nv){console.error('durate.json: '+tm.start.length+' frasi, la spec ne ha '+nv+' con voce: uso le durate stimate');tm=null}
  else{const st=[],du=[];let k=0;F.forEach((f,i)=>{if(voc[i]){st.push(tm.start[k]);du.push(tm.dur[k]);k++}else{st.push(null);du.push(null)}});
    for(let i=0;i<F.length;i++)if(st[i]===null){const prevEnd=i>0&&st[i-1]!==null?st[i-1]+du[i-1]:-LEAD+0.2;let j=i+1;while(j<F.length&&st[j]===null)j++;const nxt=j<F.length?st[j]:prevEnd+2.5;const n=j-i;const span=Math.max(1.2*n,nxt-prevEnd-0.1);for(let q=0;q<n;q++){st[i+q]=prevEnd+span*q/n;du[i+q]=span/n-0.05}i=j-1}
    tm={start:st,dur:du}}}
const b=await chromium.launch(fs.existsSync('/opt/pw-browsers/chromium')?{executablePath:'/opt/pw-browsers/chromium'}:{});const p=await b.newPage({viewport:{width:1080,height:1920}});const errs=[];p.on('pageerror',e=>errs.push(String(e)));p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await p.goto('file://'+process.cwd()+'/'+H);await p.evaluate(async()=>{for(const f of ['600 40px RS','400 30px RN','600 30px RN','500 24px RM'])await document.fonts.load(f);await document.fonts.ready});
if(SPEC){await p.evaluate(s=>load(s),SPEC);const rc=await p.evaluate(s=>window.regiaCheck?regiaCheck(s):[],SPEC);if(rc.length){console.error('REGIA, regole non rispettate:\n- '+rc.join('\n- '));process.exit(1)}}
const T=await p.evaluate(([tm,L,sp])=>tm?setupAbs(tm.start,tm.dur,L):(sp?setup(stima(),L):setup(B.map(b=>Math.max(2.2,b.t.length/13.5)),L)),[tm,LEAD,!!SPEC]);
fs.rmSync('vf',{recursive:true,force:true});fs.mkdirSync('vf');let n=0;for(let t=0;t<T;t+=1/30){await p.evaluate(t=>draw(t),t);await p.screenshot({path:'vf/'+String(n++).padStart(5,'0')+'.jpg',type:'jpeg',quality:86})}
await b.close();if(errs.length){console.error(errs.slice(0,5));process.exit(1)}
const len=n/30;execSync(`python3 musica.py ${len.toFixed(2)} mus.wav musica_originale_45s.opus`);
const voice=!!tm&&fs.existsSync('voce.wav');
const af=voice?`-i voce.wav -filter_complex "[1:a]volume=0.13[m];[2:a]adelay=${LEAD*1000}|${LEAD*1000},volume=1.3[v];[m][v]amix=inputs=2:duration=first:normalize=0,afade=t=out:st=${(len-1.5).toFixed(2)}:d=1.5,loudnorm=I=-14:TP=-1.5:LRA=11,aresample=44100[a]" -map 0:v -map "[a]"`:`-filter_complex "[1:a]volume=0.5,afade=t=out:st=${(len-1.5).toFixed(2)}:d=1.5[a]" -map 0:v -map "[a]"`;
execSync(`ffmpeg -y -v error -framerate 30 -i vf/%05d.jpg -i mus.wav ${af} -t ${len.toFixed(2)} -c:v libx264 -pix_fmt yuv420p -crf 24 -preset medium -c:a aac -b:a 128k -movflags +faststart ${out}`);
console.log(JSON.stringify({ok:true,out,secondi:+len.toFixed(1),mb:+(fs.statSync(out).size/1e6).toFixed(1),voce:voice,motore:SPEC?'spec':'video.html'}));
