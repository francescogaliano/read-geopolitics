// make.mjs sb.json out.mp4 [durate.json] — con tempi.json e voce.wav: video sincronizzato sulla voce unica
import fs from 'fs';import {execSync} from 'child_process';import os from 'os';
const cand=[process.env.PW_MODULE,os.homedir()+'/igkit/node_modules/playwright/index.mjs','/home/claude/kit/node_modules/playwright/index.mjs','/opt/npm-tools/node_modules/playwright/index.mjs'].filter(Boolean);
const {chromium}=await import(cand.find(f=>fs.existsSync(f)));
const [sbf,out,tf]=process.argv.slice(2);const H=(()=>{try{return JSON.parse(fs.readFileSync(sbf,'utf8')).html||'video.html'}catch(e){return 'video.html'}})();const LEAD=1.6;const tm=tf&&fs.existsSync(tf)?JSON.parse(fs.readFileSync(tf,'utf8')):null;
const b=await chromium.launch(fs.existsSync('/opt/pw-browsers/chromium')?{executablePath:'/opt/pw-browsers/chromium'}:{});const p=await b.newPage({viewport:{width:1080,height:1920}});const errs=[];p.on('pageerror',e=>errs.push(String(e)));
await p.goto('file://'+process.cwd()+'/'+H);await p.evaluate(async()=>{for(const f of ['600 40px RS','400 30px RN','600 30px RN','500 24px RM'])await document.fonts.load(f);await document.fonts.ready});
const T=await p.evaluate(([tm,L])=>tm?setupAbs(tm.start,tm.dur,L):setup(B.map(b=>Math.max(2.2,b.t.length/13.5)),L),[tm,LEAD]);
fs.rmSync('vf',{recursive:true,force:true});fs.mkdirSync('vf');let n=0;for(let t=0;t<T;t+=1/30){await p.evaluate(t=>draw(t),t);await p.screenshot({path:'vf/'+String(n++).padStart(5,'0')+'.jpg',type:'jpeg',quality:86})}
await b.close();if(errs.length){console.error(errs);process.exit(1)}
const len=n/30;execSync(`python3 musica.py ${len.toFixed(2)} mus.wav musica_originale_45s.mp3`);
const voice=!!tm&&fs.existsSync('voce.wav');
const af=voice?`-i voce.wav -filter_complex "[1:a]volume=0.13[m];[2:a]adelay=${LEAD*1000}|${LEAD*1000},volume=1.3[v];[m][v]amix=inputs=2:duration=first:normalize=0,afade=t=out:st=${(len-1.5).toFixed(2)}:d=1.5,loudnorm=I=-14:TP=-1.5:LRA=11,aresample=44100[a]" -map 0:v -map "[a]"`:`-filter_complex "[1:a]volume=0.5,afade=t=out:st=${(len-1.5).toFixed(2)}:d=1.5[a]" -map 0:v -map "[a]"`;
execSync(`ffmpeg -y -v error -framerate 30 -i vf/%05d.jpg -i mus.wav ${af} -t ${len.toFixed(2)} -c:v libx264 -pix_fmt yuv420p -crf 24 -preset medium -c:a aac -b:a 128k -movflags +faststart ${out}`);
console.log(JSON.stringify({ok:true,out,secondi:+len.toFixed(1),mb:+(fs.statSync(out).size/1e6).toFixed(1),voce:voice}));
