# el_voce.py sb.json — voce ElevenLabs (una sola registrazione) con i tempi esatti di ogni frase.
# Scrive voce_raw.wav e el_align.json {"start":[...],"end":[...]}; esce con codice 1 se qualcosa non va (voce.py allora usa Gemini).
# Campi del copione usati: frasi_voce, el_voce (voice_id), el_modello (default eleven_v3), el_tag (lista facoltativa, un tag per frase, es. "[curious]"),
# el_stabilita (0.0 creativa, 0.5 naturale, 1.0 stabile; default 0.5).
import sys,os,json,base64,urllib.request,urllib.error,subprocess,time
SB=json.load(open(sys.argv[1],encoding="utf-8"));F=SB["frasi_voce"];N=len(F)
key=os.environ.get("ELEVENLABS_API_KEY","").strip();vid=(SB.get("el_voce") or os.environ.get("ELEVENLABS_VOICE_ID","")).strip()
if not key or not vid: sys.exit("ElevenLabs: manca la chiave o la voce")
MODEL=SB.get("el_modello") or "eleven_v3"
# i tag tra parentesi quadre li capisce solo Eleven v3: con gli altri modelli verrebbero letti ad alta voce
EXP=MODEL.startswith(("eleven_v3","eleven_v4"))
tags=(SB.get("el_tag") or [""]*N) if EXP else [""]*N
parts=[];offs=[];txt=""
for i,f in enumerate(F):
    if i: txt+="\n\n"
    t=(tags[i] if i<len(tags) and tags[i] else "");txt+=(t+" " if t else "");offs.append(len(txt));txt+=f
body={"text":txt,"model_id":MODEL,"language_code":"it",
      "voice_settings":{"stability":float(SB.get("el_stabilita",0.5)),"similarity_boost":float(SB.get("el_somiglianza",0.85)),**({"style":float(SB.get("el_stile",0.15)),"use_speaker_boost":True} if not EXP else {})}}
url=os.environ.get("ELEVENLABS_BASE","https://api.elevenlabs.io")+f"/v1/text-to-speech/{vid}/with-timestamps?output_format=mp3_44100_128"
req=urllib.request.Request(url,data=json.dumps(body).encode(),headers={"xi-api-key":key,"content-type":"application/json","accept":"application/json","user-agent":"rg-punti/1.0"})
r=None;plain=None
for tent in range(3):
    try: r=json.load(urllib.request.urlopen(req,timeout=300));break
    except urllib.error.HTTPError as e:
        msg=e.read().decode()[:400]
        if e.code in (429,500,502,503,504) and tent<2: time.sleep(10*(tent+1));continue
        if e.code in (400,404,422) and "with-timestamps" in url:
            # il modello non dà i tempi: chiedo solo l'audio, i tempi li ricava voce.py dalle pause
            try:
                req2=urllib.request.Request(url.replace("/with-timestamps",""),data=json.dumps(body).encode(),headers={"xi-api-key":key,"content-type":"application/json","accept":"audio/mpeg","user-agent":"rg-punti/1.0"})
                plain=urllib.request.urlopen(req2,timeout=300).read();break
            except urllib.error.HTTPError as e2: sys.exit(f"ElevenLabs errore {e2.code}: {e2.read().decode()[:300]} (con i tempi: {e.code} {msg[:150]})")
        sys.exit(f"ElevenLabs errore {e.code}: {msg}")
    except Exception as e:
        if tent<2: time.sleep(10*(tent+1));continue
        sys.exit(f"ElevenLabs errore di rete: {e}")
open("voce_el.mp3","wb").write(plain if plain is not None else base64.b64decode(r["audio_base64"]))
if plain is not None: r={}
subprocess.run(["ffmpeg","-y","-v","error","-i","voce_el.mp3","-ar","24000","-ac","1","voce_raw.wav"],check=True)
def mappa(cs,st,en):
    # trova ogni frase nel testo allineato (solo lettere e cifre), così tag, spazi e punteggiatura non contano
    keep=[k for k,ch in enumerate(cs) if str(ch).isalnum()];A="".join(str(cs[k]).lower() for k in keep)
    S=[];E=[];cur=0
    for f in F:
        nf="".join(ch.lower() for ch in f if ch.isalnum())
        if not nf: return None
        a=A.find(nf[:14],cur)
        if a<0: return None
        b=A.find(nf[-10:],a)
        if b<0: return None
        b=b+min(10,len(nf))-1
        S.append(st[keep[a]]);E.append(en[keep[b]]);cur=b+1
    return S,E
res=None;fonte=None
al=r.get("normalized_alignment") or r.get("alignment") or {}
cs,st,en=al.get("characters") or [],al.get("character_start_times_seconds") or [],al.get("character_end_times_seconds") or []
if cs and len(cs)==len(st)==len(en): res=mappa(cs,st,en);fonte="timestamp"
if res is None:
    # allineamento forzato di ElevenLabs sull'audio appena generato (serve il permesso «Allineamento forzato» sulla chiave)
    try:
        import uuid
        bd="----rg"+uuid.uuid4().hex;txt_plain="\n\n".join(F)
        data=(f"--{bd}\r\nContent-Disposition: form-data; name=\"text\"\r\n\r\n{txt_plain}\r\n--{bd}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"voce.mp3\"\r\nContent-Type: audio/mpeg\r\n\r\n").encode()+open("voce_el.mp3","rb").read()+f"\r\n--{bd}--\r\n".encode()
        fa=urllib.request.Request(os.environ.get("ELEVENLABS_BASE","https://api.elevenlabs.io")+"/v1/forced-alignment",data=data,headers={"xi-api-key":key,"content-type":"multipart/form-data; boundary="+bd,"accept":"application/json","user-agent":"rg-punti/1.0"})
        j=json.load(urllib.request.urlopen(fa,timeout=300));C=j.get("characters") or []
        if C: res=mappa([c.get("text","") for c in C],[c.get("start",0) for c in C],[c.get("end",0) for c in C]);fonte="allineamento forzato"
    except Exception as e:
        print("allineamento forzato non riuscito:",str(e)[:200],file=sys.stderr)
if res:
    json.dump({"start":res[0],"end":res[1]},open("el_align.json","w"))
    print(json.dumps({"elevenlabs":True,"voce":vid,"modello":MODEL,"tempi":fonte,"caratteri":len(txt)}))
else:
    if os.path.exists("el_align.json"): os.remove("el_align.json")
    print(json.dumps({"elevenlabs":True,"voce":vid,"modello":MODEL,"tempi":"dalle pause","caratteri":len(txt)}))
