/* azioni.js — repertorio di icone (Tabler, MIT), pittogrammi di persone (stile ISOTYPE), azioni animate e scene «persone» e «illustrazione».
   Si carica dopo lo script principale di motore.html e ne usa gli aiuti (c, txt, tw, wrap, E, EB, EI, cl, sg, ph, at, D, col, COL, SC, MAPC, GBY). */
/* ---------- icone: nome Tabler, parola italiana o icona interna ---------- */
const TB=window.TABLER||{},VO=window.VOC||{};const PCACHE={};
function risolvi(k){if(!k)return null;if(String(k).startsWith("persona:"))return k;if(ICN[k])return "int:"+k;if(TB[k])return k;const w=String(k).toLowerCase().trim();if(VO[w]&&TB[VO[w]])return VO[w];
  for(const [n,v] of Object.entries(TB))if((v.tag||[]).includes(w))return n;return "point"}
function tabler(name,x,y,size,colr,a,lw){const v=TB[name];if(!v)return;if(!PCACHE[name])PCACHE[name]=v.d.map(d=>new Path2D(d));const s=size/24;c.save();c.globalAlpha*=a==null?1:a;c.translate(x-size/2,y-size/2);c.scale(s,s);
  c.strokeStyle=colr;c.lineWidth=lw||Math.max(0.9,Math.min(1.9,Math.max(4,Math.min(9,size*0.07))/s));c.lineCap="round";c.lineJoin="round";PCACHE[name].forEach(p=>c.stroke(p));c.restore()}
/* l'icona interna (icon) ora ricade su Tabler e sui pittogrammi */
const _icon=icon;icon=function(k,x,y,size,colr,lw,a){const r=risolvi(k);if(!r)return;if(r.startsWith("int:"))return _icon(k,x,y,size,colr,lw,a);if(r.startsWith("persona:"))return persona(r.slice(8),x,y+size*0.05,size*0.9,colr,a);return tabler(r,x,y,size,colr,a)};
function disegna(k,x,y,size,colr,a){k=String(k);if(k.startsWith("obj:"))return oggetto(k.slice(4),x,y,size,colr,a);if(k.startsWith("cal:"))return calendario(k.slice(4),x,y,size,a);icon(k,x,y,size,colr,5,a)}
/* oggetti disegnati a mano, riconoscibili: urna con scheda, cartella sigillata */
function oggetto(tipo,x,y,s,colr,a){c.save();c.globalAlpha*=a==null?1:a;c.translate(x,y);const u=s/100;c.lineWidth=Math.max(4,5*u);c.strokeStyle=colr;c.lineJoin="round";
  if(tipo==="urna"){rr(-46*u,-20*u,92*u,62*u,8*u);c.fillStyle="#16243a";c.fill();c.stroke();rr(-52*u,-30*u,104*u,12*u,6*u);c.fillStyle="#1d2e48";c.fill();c.stroke();c.fillStyle="#0a0f18";c.fillRect(-22*u,-27*u,44*u,6*u);
    rr(-16*u,-58*u,32*u,40*u,3*u);c.fillStyle="#EEF2F6";c.fill();c.strokeStyle="#9fb3cf";c.lineWidth=2.5*u;c.stroke();c.strokeStyle="#2f7fd0";c.lineWidth=4*u;c.beginPath();c.moveTo(-8*u,-40*u);c.lineTo(-2*u,-33*u);c.lineTo(9*u,-48*u);c.stroke();
    c.strokeStyle=colr;c.lineWidth=Math.max(3,3*u);c.beginPath();c.moveTo(-30*u,10*u);c.lineTo(30*u,10*u);c.stroke()}
  else if(tipo==="scheda"){rr(-30*u,-40*u,60*u,80*u,5*u);c.fillStyle="#EEF2F6";c.fill();c.strokeStyle="#9fb3cf";c.lineWidth=3*u;c.stroke();for(let i=0;i<3;i++){c.strokeStyle="#9fb3cf";c.strokeRect(-20*u,(-24+i*20)*u,10*u,10*u);c.fillStyle="#9fb3cf";c.fillRect(-4*u,(-21+i*20)*u,26*u,4*u)}
    c.strokeStyle="#2f7fd0";c.lineWidth=4*u;c.beginPath();c.moveTo(-19*u,-1*u);c.lineTo(-15*u,3*u);c.lineTo(-8*u,-6*u);c.stroke()}
  else if(tipo==="cartella"){c.beginPath();c.moveTo(-48*u,-30*u);c.lineTo(-14*u,-30*u);c.lineTo(-6*u,-22*u);c.lineTo(48*u,-22*u);c.lineTo(48*u,34*u);c.lineTo(-48*u,34*u);c.closePath();c.fillStyle="#3b2e1a";c.fill();c.strokeStyle="#E8A33D";c.stroke();
    c.beginPath();c.arc(20*u,14*u,13*u,0,7);c.fillStyle="#E8A33D";c.fill();c.fillStyle="#3b2e1a";c.beginPath();c.arc(20*u,14*u,6*u,0,7);c.fill()}
  else if(tipo==="knesset"){c.lineWidth=Math.max(3,3.5*u);c.fillStyle="#16243a";
    rr(-70*u,22*u,140*u,10*u,2*u);c.fill();c.stroke();rr(-78*u,32*u,156*u,8*u,2*u);c.fill();c.stroke();
    rr(-64*u,-26*u,128*u,12*u,2*u);c.fillStyle="#1d2e48";c.fill();c.stroke();
    for(let i=0;i<9;i++){const xx=(-56+i*14)*u;c.fillStyle=colr;c.fillRect(xx-3*u,-14*u,6*u,36*u)}
    c.fillStyle="#0a0f18";c.fillRect(-8*u,4*u,16*u,18*u);
    const my=-34*u;c.beginPath();c.moveTo(0,my);c.lineTo(0,my-30*u);for(let k=1;k<=3;k++){c.moveTo(-k*7*u,my-30*u);c.quadraticCurveTo(-k*7*u,my,0,my);c.quadraticCurveTo(k*7*u,my,k*7*u,my-30*u)}c.moveTo(-10*u,my);c.lineTo(10*u,my);c.strokeStyle="#E8A33D";c.stroke()}
  else if(tipo==="tavolo"){c.lineWidth=Math.max(3,3.5*u);
    const sedia=(sx,f)=>{c.save();c.translate(sx*u,0);c.scale(f,1);c.fillStyle="#1d2e48";c.strokeStyle="#EEF2F6";rr(-10*u,-38*u,8*u,58*u,3*u);c.fill();c.stroke();rr(-10*u,4*u,28*u,7*u,3*u);c.fill();c.stroke();c.beginPath();c.moveTo(14*u,11*u);c.lineTo(14*u,30*u);c.moveTo(-6*u,11*u);c.lineTo(-6*u,30*u);c.stroke();c.restore()};
    sedia(-70,1);sedia(70,-1);
    c.beginPath();c.moveTo(-56*u,-6*u);c.lineTo(56*u,-6*u);c.lineTo(42*u,-24*u);c.lineTo(-42*u,-24*u);c.closePath();c.fillStyle="#3b2e1a";c.fill();c.strokeStyle=colr;c.stroke();
    rr(-56*u,-6*u,112*u,6*u,1*u);c.fillStyle=colr;c.fill();
    c.beginPath();c.moveTo(-48*u,0);c.lineTo(-48*u,34*u);c.moveTo(48*u,0);c.lineTo(48*u,34*u);c.moveTo(-34*u,-20*u);c.lineTo(-34*u,22*u);c.moveTo(34*u,-20*u);c.lineTo(34*u,22*u);c.stroke();
    c.save();c.translate(-16*u,-16*u);c.rotate(-0.1);c.fillStyle="#EEF2F6";c.fillRect(-9*u,-4*u,18*u,8*u);c.restore();c.save();c.translate(16*u,-16*u);c.rotate(0.1);c.fillStyle="#EEF2F6";c.fillRect(-9*u,-4*u,18*u,8*u);c.restore()}
  else if(tipo==="scrivania"){c.lineWidth=Math.max(3,3.5*u);c.fillStyle="#3b2e1a";c.strokeStyle=colr;
    c.beginPath();c.moveTo(-62*u,-4*u);c.lineTo(62*u,-4*u);c.lineTo(50*u,-20*u);c.lineTo(-50*u,-20*u);c.closePath();c.fill();c.stroke();
    rr(-62*u,-4*u,124*u,44*u,3*u);c.fill();c.stroke();c.beginPath();c.moveTo(0,-4*u);c.lineTo(0,40*u);c.stroke();
    c.fillStyle=colr;c.fillRect(-36*u,16*u,14*u,4*u);c.fillRect(22*u,16*u,14*u,4*u);
    for(let i=0;i<3;i++){c.save();c.translate((-24+i*3)*u,(-24-i*4)*u);c.rotate(-0.06+i*0.05);c.fillStyle="#EEF2F6";c.fillRect(-16*u,-3*u,32*u,6*u);c.strokeStyle="#9fb3cf";c.lineWidth=1.5*u;c.strokeRect(-16*u,-3*u,32*u,6*u);c.restore()}
    c.fillStyle="#E8A33D";rr(14*u,-30*u,30*u,10*u,2*u);c.fill()}
  else if(tipo==="fogli"){for(let i=0;i<3;i++){c.save();c.translate(i*5*u,i*-5*u);rr(-28*u,-36*u,56*u,72*u,4*u);c.fillStyle="#EEF2F6";c.fill();c.strokeStyle="#9fb3cf";c.lineWidth=3*u;c.stroke();c.restore()}
    for(let k=0;k<4;k++){c.fillStyle="#9fb3cf";c.fillRect(-8*u,(-30+k*14)*u,40*u,4*u)}}
  c.restore()}
/* calendario a foglio: "NOV|4" */
function calendario(v,x,y,s,a){const [m,d]=String(v).split("|");const u=s/200;c.save();c.globalAlpha*=a==null?1:a;c.translate(x,y);c.scale(u,u);rr(-110,-100,220,210,24);c.fillStyle=COL.fondo;c.fill();c.lineWidth=5;c.strokeStyle=COL.bordo;c.stroke();rr(-110,-100,220,56,[24,24,0,0]);c.fillStyle=COL.oro;c.fill();
  txt(m,0,-60,"600 30px RM","#1a1000","center",1,true);txt(d,0,76,"600 116px RS",COL.bianco,"center",1,true);c.restore()}
/* ---------- pittogrammi di persone (pieni, stile ISOTYPE) ---------- */
/* h = altezza totale; (x,y) = centro dei piedi */
function persona(tipo,x,y,h,colr,a){tipo=tipo||"uomo";const s=h/100;c.save();c.globalAlpha*=a==null?1:a;c.translate(x,y);c.scale(s,s);c.fillStyle=colr;
  const testa=(cx,cy,r)=>{c.beginPath();c.arc(cx,cy,r,0,7);c.fill()};
  const busto=(w1,w2,y0,y1,r)=>{c.beginPath();c.moveTo(-w1/2+r,y0);c.lineTo(w1/2-r,y0);c.quadraticCurveTo(w1/2,y0,w1/2,y0+r);c.lineTo(w2/2,y1);c.lineTo(-w2/2,y1);c.lineTo(-w1/2,y0+r);c.quadraticCurveTo(-w1/2,y0,-w1/2+r,y0);c.closePath();c.fill()};
  const gambe=(w,y0,gap)=>{c.fillRect(-w/2,y0,w/2-gap/2,-y0);c.fillRect(gap/2,y0,w/2-gap/2,-y0)};
  if(tipo==="bambino"){testa(0,-56,11);busto(30,24,-43,-18,8);gambe(22,-20,4)}
  else if(tipo==="donna"){testa(0,-86,12);busto(26,44,-71,-34,9);gambe(20,-36,5)}
  else if(tipo==="anziano"){c.save();c.rotate(0.08);testa(2,-82,12);busto(34,28,-67,-36,10);gambe(26,-38,5);c.restore();c.fillRect(22,-50,4,50);c.beginPath();c.arc(17,-50,6,Math.PI,0);c.lineWidth=4;c.strokeStyle=colr;c.stroke()}
  else if(tipo==="soldato"){testa(0,-84,12);c.beginPath();c.ellipse(0,-90,16,8,0,Math.PI,0);c.fill();c.fillRect(-18,-91,36,4);busto(38,30,-70,-38,10);gambe(30,-40,5)}
  else if(tipo==="lavoratore"){testa(0,-84,12);c.beginPath();c.arc(0,-90,14,Math.PI,0);c.fill();c.fillRect(-18,-91,36,4);busto(38,30,-70,-38,10);gambe(30,-40,5)}
  else if(tipo==="medico"){testa(0,-86,12);busto(38,30,-71,-38,10);gambe(30,-40,5);c.fillStyle="#0e1626";c.fillRect(-2.5,-64,5,16);c.fillRect(-8,-58.5,16,5)}
  else if(tipo==="folla"){[[-20,0.85,0.55],[20,0.85,0.55],[0,1,1]].forEach(([dx,sc,al])=>{c.save();c.globalAlpha*=al;c.translate(dx,0);c.scale(sc,sc);testa(0,-86,12);busto(38,30,-71,-38,10);gambe(30,-40,5);c.restore()})}
  else if(["abito","delegato","netanyahu","eisenkot","abbas","herzog"].includes(tipo)){testa(0,-86,12);busto(38,30,-71,-38,10);gambe(30,-40,5);
    c.fillStyle="#EEF2F6";c.beginPath();c.moveTo(-6,-71);c.lineTo(6,-71);c.lineTo(0,-56);c.closePath();c.fill();c.fillStyle="#0e1626";c.beginPath();c.moveTo(-2,-69);c.lineTo(2,-69);c.lineTo(3,-54);c.lineTo(0,-50);c.lineTo(-3,-54);c.closePath();c.fill();
    if(tipo==="delegato"){c.fillStyle="#E8A33D";rr(14,-56,16,20,2);c.fill();c.fillStyle="#3b2e1a";c.fillRect(17,-50,10,2)}
    if(tipo==="netanyahu"||tipo==="abbas"){c.fillStyle="#cfd8e3";c.beginPath();c.arc(0,-87,12.5,Math.PI*1.05,Math.PI*1.95);c.fill()}
    if(tipo==="eisenkot"||tipo==="abbas"){c.strokeStyle="#0e1626";c.lineWidth=1.8;c.beginPath();c.arc(-5,-86,3.6,0,7);c.moveTo(8.6,-86);c.arc(5,-86,3.6,0,7);c.moveTo(-1.4,-86);c.lineTo(1.4,-86);c.stroke()}
    if(tipo==="abbas"){c.fillStyle="#cfd8e3";c.fillRect(-5,-80,10,2.6)}}
  else{testa(0,-86,12);busto(38,30,-71,-38,10);gambe(30,-40,5)}
  c.restore()}
/* ---------- scena «persone»: quantità rappresentate da pittogrammi ---------- */
SC.persone=(t,S)=>{const p=S.p,G=p.gruppi||[];const tot=G.reduce((a,g)=>a+g.n,0);const cols=p.colonne||Math.min(10,Math.max(5,Math.ceil(Math.sqrt(tot*1.6))));const rows=Math.ceil(tot/cols);
  const legH=p.legenda?70:0;const avail=1700-S.top-60-legH-(G.length>1||G[0]&&G[0].valore?170:40);const ph0=Math.min(180,avail/rows*0.86,880/cols/0.5);const cw=ph0*0.5,rh=ph0/0.86;
  const W=cols*cw,x0=540-W/2+cw/2;const blockH=rows*rh+legH+(G.length>1||G[0]&&G[0].valore?200:40);const y0=S.top+60+ph0+Math.max(0,(1700-S.top-60-blockH)*0.35);let k=0;c.save();c.globalAlpha*=E(ph(t,S.i0,-0.2,0.4));
  G.forEach((g,gi)=>{const ps=g.passo||0;for(let q=0;q<g.n;q++,k++){const x=x0+(k%cols)*cw,y=y0+Math.floor(k/cols)*rh;const e=EB(ph(t,S.i0+ps,0.15+q*Math.min(0.06,1.4/g.n),0.5+q*Math.min(0.06,1.4/g.n)));if(e<=0)continue;
    c.save();c.translate(x,y);c.scale(cl(e)*0.4+0.6*e,e);persona(g.tipo||p.tipo,0,0,ph0,col(g.colore||"azz"),cl(e));c.restore()}});
  let yL=y0+(rows-1)*rh+60;if(p.legenda){const e=E(ph(t,S.i0,0.4,0.9));persona(p.tipo||G[0].tipo,330,yL+44,52,COL.grigio,e);txt("= "+p.legenda,360,yL+30,"500 30px RM",COL.grigio,"left",e);yL+=legH}
  const n=G.length;G.forEach((g,gi)=>{if(!g.valore&&n<2)return;const e=E(ph(t,S.i0+(g.passo||0),0.6,1.1));if(e<=0)return;const x=540+(gi-(n-1)/2)*Math.min(330,900/n);
    txt(g.valore||String(g.n),x,yL+80,"600 "+(n>2?70:96)+"px RS",col(g.colore||"azz"),"center",e);wrap(g.etichetta||"","500 28px RM",n<2?760:Math.min(320,900/n)-10).forEach((l,m)=>txt(l,x,yL+124+m*36,"500 28px RM",COL.grigio,"center",e))});c.restore()};
/* ---------- azioni ---------- */
const RNDA=s=>{let x=s*9301+49297;return()=>(x=(x*16807)%2147483647)/2147483647};
function tAz(S,q){const j=q.frase??q.passo??0;const du=D[S.i0+j]||3;return at(S.i0+j,(q.f??0.2)*du+(q.dt||0))}
/* esplosione: lampo, onda, schegge, fumo; niente sangue né vittime */
function esplosione(x,y,k,size,seed){size=size||1;if(k<=0||k>=1)return;const r=RNDA(seed||7);c.save();
  const fl=1-cl(k*5);if(fl>0){const g=c.createRadialGradient(x,y,0,x,y,120*size);g.addColorStop(0,"rgba(255,244,214,"+fl+")");g.addColorStop(.4,"rgba(232,163,61,"+fl*0.8+")");g.addColorStop(1,"rgba(232,163,61,0)");c.fillStyle=g;c.beginPath();c.arc(x,y,120*size,0,7);c.fill()}
  const w=E(k);c.strokeStyle="rgba(255,220,170,"+(1-k)*0.8+")";c.lineWidth=6*size*(1-k)+1;c.beginPath();c.arc(x,y,30*size+170*size*w,0,7);c.stroke();
  for(let i=0;i<14;i++){const an=r()*6.28,sp=(90+r()*140)*size;const px=x+Math.cos(an)*sp*E(k),py=y+Math.sin(an)*sp*E(k)+60*size*k*k;c.fillStyle="rgba(232,163,61,"+(1-k)+")";c.beginPath();c.arc(px,py,(5+r()*5)*size*(1-k*0.6),0,7);c.fill()}
  for(let i=0;i<5;i++){const an=-Math.PI/2+(r()-0.5)*1.6,d=(40+r()*60)*size*E(k);c.fillStyle="rgba(120,132,150,"+0.45*Math.sin(Math.PI*cl(k*1.2))+")";c.beginPath();c.arc(x+Math.cos(an)*d,y+Math.sin(an)*d-40*size*k,(26+r()*20)*size*(0.5+k),0,7);c.fill()}c.restore()}
function curva(a,b,alt){const mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2-(alt??Math.hypot(b[0]-a[0],b[1]-a[1])*0.35);return u=>[(1-u)*(1-u)*a[0]+2*u*(1-u)*mx+u*u*b[0],(1-u)*(1-u)*a[1]+2*u*(1-u)*my+u*u*b[1]]}
function segm(P){const L=[0];for(let i=1;i<P.length;i++)L.push(L[i-1]+Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]));const T=L[L.length-1]||1;return u=>{const d=u*T;let i=1;while(i<P.length-1&&L[i]<d)i++;const f=(d-L[i-1])/((L[i]-L[i-1])||1);return [P[i-1][0]+(P[i][0]-P[i-1][0])*f,P[i-1][1]+(P[i][1]-P[i-1][1])*f]}}
const AZ={};
/* lancio: traiettoria ad arco con scia; all'arrivo esplosione (esplodi:false per non farla) */
AZ.lancio=(t,q,S,pos)=>{const n=q.n||1;for(let m=0;m<n;m++){const t0=tAz(S,q)+m*(q.ogni??0.35),du=q.durata||1.3;const k=(t-t0)/du;const a=pos(q.da),b0=pos(q.a);if(!a||!b0)continue;const b=[b0[0]+((m%3)-1)*(q.spargi??30),b0[1]+((m%2)?-1:1)*(q.spargi??30)*0.5];
  const f=curva(a,b,q.alt);if(k>0&&k<1){const u=EI(k);c.save();c.strokeStyle="rgba(232,163,61,.55)";c.lineWidth=5;c.setLineDash([2,12]);c.lineCap="round";c.beginPath();for(let s=Math.max(0,u-0.35);s<=u;s+=0.02){const P=f(s);s===Math.max(0,u-0.35)?c.moveTo(...P):c.lineTo(...P)}c.stroke();c.restore();
    const P=f(u),P2=f(Math.min(1,u+0.01));const an=Math.atan2(P2[1]-P[1],P2[0]-P[0]);c.save();c.translate(P[0],P[1]);c.rotate(an+Math.PI/4);tabler(risolvi(q.icona||"rocket"),0,0,q.size||70,col(q.colore||"bianco"),1);c.restore()}
  if(q.esplodi!==false)esplosione(b[0],b[1],(t-t0-du)/1.4,q.forza||1,m+3)}};
AZ.esplosione=(t,q,S,pos)=>{const P=pos(q.a||q.da);if(P)esplosione(P[0],P[1],(t-tAz(S,q))/(q.durata||1.4),q.forza||1,5)};
/* attraversa: un'icona percorre un tragitto (punti, id o coordinate) */
AZ.attraversa=(t,q,S,pos)=>{const P=(q.percorso||[q.da,q.a]).map(pos).filter(Boolean);if(P.length<2)return;const k=(t-tAz(S,q))/(q.durata||2.4);if(k<=0)return;const f=segm(P),u=EI(cl(k));
  if(q.traccia){c.save();c.strokeStyle="rgba(134,180,234,.45)";c.setLineDash([10,10]);c.lineWidth=4;c.beginPath();for(let s=0;s<=u;s+=0.02){const p=f(s);s?c.lineTo(...p):c.moveTo(...p)}c.stroke();c.restore();}
  const p=f(u),p2=f(Math.min(1,u+0.02));const fl=q.specchia!==false&&p2[0]<p[0];forma({id:q.id||"mobile",tipo:"oggetto",su:q.su,box:S._box},()=>{c.save();c.translate(p[0],p[1]);if(fl)c.scale(-1,1);disegna(q.icona||"nave",0,0,q.size||110,col(q.colore||"oro"),1);c.restore()})};
/* spezza: l'elemento si divide in due metà che cadono, con polvere */
AZ.spezza=(t,q,S,pos,el)=>{const e=el[q.a];if(!e)return;const k=cl((t-tAz(S,q))/(q.durata||1.6));e._nascosto=k>0;if(k<=0)return;const [x,y]=pos(q.a),s=e.size||200;
  [-1,1].forEach(sd=>{c.save();c.beginPath();sd<0?c.rect(x-s,y-s,s-6,2*s):c.rect(x+6,y-s,s,2*s);c.clip();c.translate(x+sd*s*0.5,y+s*0.3);c.rotate(sd*0.5*EI(k));c.translate(-(x+sd*s*0.5),-(y+s*0.3)+90*EI(k)*EI(k));disegna(e.icona,x,y,s,col(e.colore||"azz"),1);c.restore()});
  c.save();c.strokeStyle="rgba(255,220,170,"+(1-k)+")";c.lineWidth=5;c.beginPath();c.moveTo(x-4,y-s*0.4);c.lineTo(x+8,y-s*0.1);c.lineTo(x-6,y+s*0.15);c.lineTo(x+4,y+s*0.4);c.stroke();c.restore();
  const r=RNDA(11);for(let i=0;i<10;i++){c.fillStyle="rgba(140,150,165,"+0.4*(1-k)+")";c.beginPath();c.arc(x+(r()-0.5)*s,y+s*0.3+r()*60*k,(14+r()*16)*(0.5+k),0,7);c.fill()}};
/* blocca: barriera che cala davanti all'elemento o sul percorso */
AZ.blocca=(t,q,S,pos)=>{const P=pos(q.a);if(!P)return;const k=EB(cl((t-tAz(S,q))/0.7));if(k<=0)return;c.save();c.globalAlpha*=cl(k);c.translate(P[0],P[1]-(1-cl(k))*120);
  const w=q.larghezza||200;c.fillStyle=COL.fondo;rr(-w/2,-34,w,68,14);c.fill();c.lineWidth=5;c.strokeStyle=col(q.colore||"bianco");c.stroke();for(let i=-w/2+16;i<w/2-10;i+=40){c.beginPath();c.moveTo(i,30);c.lineTo(i+26,-30);c.stroke()}
  if(q.etichetta)txt(q.etichetta,0,80,"600 30px RM",col(q.colore||"bianco"),"center");c.restore()};
/* scambia: due oggetti si incrociano tra due punti */
AZ.scambia=(t,q,S,pos)=>{const a=pos(q.da),b=pos(q.a);if(!a||!b)return;const k=(t-tAz(S,q))/(q.durata||1.8);if(k<=0)return;const u=EI(cl(k));const f1=curva(a,b,120),f2=curva(b,a,-120);
  [[f1,q.icona||"pacco",q.colore||"oro"],[f2,q.icona2||q.icona||"soldi",q.colore2||"azz"]].forEach(([f,ic,cc])=>{const P=f(u);c.save();c.strokeStyle="rgba(134,180,234,.35)";c.setLineDash([8,10]);c.lineWidth=3;c.beginPath();for(let s=0;s<=u;s+=0.03){const p=f(s);s?c.lineTo(...p):c.moveTo(...p)}c.stroke();c.restore();disegna(ic,P[0],P[1],q.size||80,col(cc),1)})};
/* cresci / cala: scala dell'elemento con freccia */
AZ.cresci=(t,q,S,pos,el)=>{const e=el[q.a];if(!e)return;const k=E(cl((t-tAz(S,q))/(q.durata||1.2)));e._scala=1+((q.fino??1.5)-1)*k;if(q.freccia!==false&&k>0){const P=pos(q.a),s=(e.size||160)*e._scala;tabler(q.azione==="cala"?"trending-down":"trending-up",P[0]+s*0.62,P[1]-s*0.45,70,col(q.colore||"oro"),k)}};
AZ.cala=(t,q,S,pos,el)=>AZ.cresci(t,{...q,fino:q.fino??0.6,azione:"cala"},S,pos,el);
/* folla: persone che compaiono attorno a un punto */
AZ.folla=(t,q,S,pos)=>{const P=pos(q.a);if(!P)return;forma({id:q.id||"folla",tipo:"gruppo",su:q.su,box:S._box},()=>AZ._folla(t,q,S,P))};
AZ._folla=(t,q,S,P)=>{const n=q.n||12,t0=tAz(S,q);const r=RNDA(21);const H=q.size||70;const cols=q.cols||Math.ceil(Math.sqrt(n*2));
  for(let i=0;i<n;i++){const gx=(i%cols-(cols-1)/2)*H*0.55+(r()-0.5)*10,gy=Math.floor(i/cols)*H*0.5;const e=EB(cl((t-t0-i*0.05)/0.4));if(e<=0)continue;c.save();c.translate(P[0]+gx,P[1]+gy);c.scale(e,e);persona(q.tipo||["uomo","donna","uomo","bambino","anziano"][i%5],0,0,H,col(q.colori?q.colori[i%q.colori.length]:(q.colore||"azz")),cl(e)*(0.75+0.25*((i+1)%2)));c.restore()}};
/* accendi / spegni: alone di energia o buio con barra */
AZ.accendi=(t,q,S,pos,el)=>{const e=el[q.a];if(!e)return;const k=cl((t-tAz(S,q))/0.8);const on=q.azione!=="spegni";e._luce=on?k:-k;const P=pos(q.a),s=e.size||160;
  if(on&&k>0){const g=c.createRadialGradient(P[0],P[1],0,P[0],P[1],s);g.addColorStop(0,"rgba(232,163,61,"+0.35*k+")");g.addColorStop(1,"rgba(232,163,61,0)");c.fillStyle=g;c.beginPath();c.arc(P[0],P[1],s,0,7);c.fill()}
  if(!on&&k>0){c.save();c.globalAlpha*=k;c.strokeStyle=COL.bianco;c.lineWidth=7;c.lineCap="round";c.beginPath();c.moveTo(P[0]-s*0.45,P[1]-s*0.45);c.lineTo(P[0]-s*0.45+s*0.9*E(k),P[1]-s*0.45+s*0.9*E(k));c.stroke();c.restore()}};
AZ.spegni=(t,q,S,pos,el)=>AZ.accendi(t,{...q,azione:"spegni"},S,pos,el);
/* conta: contatore legato a icone che si moltiplicano in fila */
AZ.conta=(t,q,S,pos)=>{const P=pos(q.a);if(!P)return;const k=E(cl((t-tAz(S,q))/(q.durata||1.6)));if(k<=0)return;const n=q.n||5,sz=q.size||60;const m=Math.round(n*k);
  for(let i=0;i<m;i++)disegna(q.icona||"persona:uomo",P[0]+(i-(n-1)/2)*sz*0.9,P[1],sz,col(q.colore||"oro"),1);
  if(q.valore!=null){const v=typeof q.valore==="number"?fmt(q.valore*k,q.decimali):q.valore;txt((q.prefisso||"")+v+(q.suffisso||""),P[0],P[1]+sz+70,"600 90px RS",col(q.colore||"oro"),"center")}
  if(q.etichetta)txt(q.etichetta,P[0],P[1]+sz+(q.valore!=null?116:60),"500 28px RM",COL.grigio,"center")};
/* evidenzia: anello pulsante attorno a un elemento o a un punto */
AZ.evidenzia=(t,q,S,pos)=>{const P=pos(q.a);if(!P)return;const k=cl((t-tAz(S,q))/0.6);if(k<=0)return;const pu=1+0.08*Math.sin(t*5);c.save();c.globalAlpha*=k;c.strokeStyle=col(q.colore||"oro");c.lineWidth=5;c.beginPath();c.arc(P[0],P[1],(q.raggio||110)*pu,0,7);c.stroke();c.restore()};
/* ---------- sfondi ---------- */
function sfondo(tipo,X0,Y0,X1,Y1,t,S,p){c.save();rr(X0,Y0,X1-X0,Y1-Y0,36);c.clip();const gy=Y0+(Y1-Y0)*(p.orizzonte??0.68);
  if(tipo==="mappa"){c.restore();SC.mappa(t,{...S,p:{...p.mappa,basso:Y1},top:Y0-20});return}
  c.fillStyle="#0c1322";c.fillRect(X0,Y0,X1-X0,Y1-Y0);
  if(tipo==="mare"){const g=c.createLinearGradient(0,gy,0,Y1);g.addColorStop(0,"#16304f");g.addColorStop(1,"#0c1a2e");c.fillStyle=g;c.fillRect(X0,gy,X1-X0,Y1-gy);c.strokeStyle="rgba(134,180,234,.25)";c.lineWidth=3;
    for(let r=0;r<5;r++){c.beginPath();for(let x=X0;x<=X1;x+=12){const y=gy+20+r*((Y1-gy)/5)+Math.sin(x/40+t*1.5+r)*5;x===X0?c.moveTo(x,y):c.lineTo(x,y)}c.stroke()}
    if(p.costa){c.fillStyle="#1a2638";c.beginPath();c.moveTo(X0,gy-6);c.lineTo(X0+(X1-X0)*0.32,gy-6);c.lineTo(X0+(X1-X0)*0.26,Y0+(gy-Y0)*0.55);c.lineTo(X0,Y0+(gy-Y0)*0.5);c.fill();c.beginPath();c.moveTo(X1,gy-6);c.lineTo(X1-(X1-X0)*0.32,gy-6);c.lineTo(X1-(X1-X0)*0.24,Y0+(gy-Y0)*0.6);c.lineTo(X1,Y0+(gy-Y0)*0.55);c.fill()}}
  else{c.fillStyle="#141f31";c.fillRect(X0,gy,X1-X0,Y1-gy);c.strokeStyle="#24324a";c.lineWidth=3;c.beginPath();c.moveTo(X0,gy);c.lineTo(X1,gy);c.stroke()}
  if(tipo==="città"||tipo==="citta"){const r=RNDA(4);let x=X0+10;while(x<X1-10){const w=50+r()*70,h=60+r()*220;c.fillStyle="#1a2638";c.fillRect(x,gy-h,w,h);c.fillStyle="rgba(232,163,61,.25)";for(let wy=gy-h+18;wy<gy-14;wy+=30)for(let wx=x+10;wx<x+w-12;wx+=22)if(r()<0.35)c.fillRect(wx,wy,8,12);x+=w+6}}
  if(tipo==="fronte"){c.setLineDash([16,12]);c.strokeStyle="rgba(238,242,246,.5)";c.lineWidth=4;c.beginPath();c.moveTo((X0+X1)/2,Y0+30);c.lineTo((X0+X1)/2,Y1-30);c.stroke();c.setLineDash([]);
    if(p.sinistra)txt(p.sinistra,X0+40,Y0+60,"600 30px RM",COL.grigio,"left");if(p.destra)txt(p.destra,X1-40,Y0+60,"600 30px RM",COL.grigio,"right")}
  if(tipo==="fiume"){c.fillStyle="#16304f";c.fillRect(X0,gy+10,X1-X0,(Y1-gy)*0.55);c.strokeStyle="rgba(134,180,234,.25)";c.lineWidth=3;for(let r=0;r<3;r++){c.beginPath();for(let x=X0;x<=X1;x+=12){const y=gy+40+r*36+Math.sin(x/40+t*1.5+r)*4;x===X0?c.moveTo(x,y):c.lineTo(x,y)}c.stroke()}}
  c.restore();rr(X0,Y0,X1-X0,Y1-Y0,36);c.lineWidth=3;c.strokeStyle="#24324a";c.stroke()}
/* ---------- scena «illustrazione»: sfondo + elementi + azioni ---------- */
SC.illustrazione=(t,S)=>{const p=S.p;const X0=60,X1=1020,Y0=S.top+20,Y1=Math.min(1740,p.basso||(p.altezza?Y0+p.altezza:1740));c.save();
  S._box={x0:X0,y0:Y0,x1:X1,y1:Y1};sfondo(p.sfondo||"orizzonte",X0,Y0,X1,Y1,t,S,p);const M=p.sfondo==="mappa"?MAPC[S.i0]:null;
  /* tutte le versioni degli elementi (scena base + passi), per impaginare il gruppo una sola volta */
  const VER=[];(p.elementi||[]).forEach(e=>VER.push({...e,_v:e.id+"#0",passo:e.passo||0}));const last={};VER.forEach(v=>last[v.id]=v);
  (S.steps||[]).forEach((st,j)=>{if(j>0)(st.elementi||[]).forEach(e=>{const pr=last[e.id];const v={...(pr||{}),...e,passo:e.passo??j,f:e.f??(pr?0:0.1),_v:e.id+"#"+j};last[e.id]=v;VER.push(v)})});
  let csI=0;for(let j=0;j<S.n;j++)if(t>=at(S.i0+j,-0.1))csI=j;const el={};VER.forEach(v=>{if(v.passo<=csI||v._v.endsWith("#0"))if(!el[v.id]||v.passo<=csI)el[v.id]=v});
  const AZS=[...(p.azioni||[])];(S.steps||[]).forEach((st,j)=>{if(j>0)(st.azioni||[]).forEach(q=>AZS.push({...q,frase:q.frase??j}))});
  const pos0=r=>{if(r==null)return null;if(Array.isArray(r)){if(r[0]>=0&&r[0]<=1&&r[1]>=0&&r[1]<=1)return [X0+(X1-X0)*r[0],Y0+(Y1-Y0)*r[1]];return M?M.pr(r):null}const e=typeof r==="string"?el[r]:r;if(!e)return null;if(e.lonlat&&M)return M.pr(e.lonlat);return [X0+(X1-X0)*e.x,Y0+(Y1-Y0)*e.y]};
  const drawEl=(e,P,s,k)=>{c.save();c.translate(P[0],P[1]);const sc=cl(k)*0.3+0.7*k;c.scale(sc,sc);if(e.cerchio){c.beginPath();c.arc(0,0,s*0.62,0,7);c.fillStyle=COL.fondo;c.fill();c.lineWidth=4;c.strokeStyle=col(e.bordo||"azz");c.stroke()}
    disegna(e.icona,0,0,s,col(e.colore||"azz"),1);c.restore()};
  /* impaginazione: misura i pixel veri di ogni versione + etichette + folle + oggetti in movimento, poi scala e centra il gruppo nella scheda (margine 40 px) */
  if(!S.L){const L={bb:{},s:1,dx:0,dy:0};const U={x0:1e9,y0:1e9,x1:-1e9,y1:-1e9};const add=b=>{if(!b)return;U.x0=Math.min(U.x0,b.x0);U.y0=Math.min(U.y0,b.y0);U.x1=Math.max(U.x1,b.x1);U.y1=Math.max(U.y1,b.y1)};
    VER.forEach(v=>{if(v.nascosto||!v.icona)return;const P=pos0(v);if(!P)return;const b=mascheraDi(()=>drawEl(v,P,v.size||160,1));if(!b)return;L.bb[v._v]={x0:b.x0,y0:b.y0,x1:b.x1,y1:b.y1};add(b);
      if(v.etichetta){const LL=String(v.etichetta).split("\n");const lw=Math.max(...LL.map(l=>tw(l,"600 34px RM")))+36,cx=(b.x0+b.x1)/2+(v.dx||0);add({x0:cx-lw/2,y0:b.y1+(v.dy||0),x1:cx+lw/2,y1:b.y1+(v.dy||0)+80+(LL.length-1)*44})}});
    AZS.forEach(q=>{if(q.azione==="folla"){const P=pos0(q.a);if(P)add(mascheraDi(()=>AZ._folla(1e6,q,S,P)))}
      if(q.azione==="attraversa"){const P=(q.percorso||[q.da,q.a]).map(pos0).filter(Boolean);[P[0],P[P.length-1]].forEach(pp=>pp&&add(mascheraDi(()=>disegna(q.icona||"nave",pp[0],pp[1],q.size||110,"#fff",1))))}});
    if(!M&&U.x1>U.x0){const ix0=X0+40,ix1=X1-40,iy0=Y0+40,iy1=Y1-40;const s=Math.min(p.zoom_max||1.6,(ix1-ix0)/(U.x1-U.x0),(iy1-iy0)/(U.y1-U.y0));L.s=s;L.dx=(ix0+ix1)/2-s*(U.x0+U.x1)/2;L.dy=(iy0+iy1)/2-s*(U.y0+U.y1)/2}
    S.L=L}
  const L=S.L,TT=P=>P&&[L.dx+L.s*P[0],L.dy+L.s*P[1]];const pos=r=>TT(pos0(r));
  c.save();rr(X0,Y0,X1-X0,Y1-Y0,36);c.clip();Object.values(el).forEach(e=>{e._scala=1;e._luce=0;e._nascosto=false});
  AZS.filter(q=>["cresci","cala","accendi","spegni"].includes(q.azione)).forEach(q=>AZ[q.azione](t,q,S,pos,el));
  AZS.filter(q=>q.azione==="spezza").forEach(q=>{const e=el[q.a];if(e)e._nascosto=t>=tAz(S,q)});
  const sq=q=>({...q,size:(q.size||(q.azione==="folla"?70:110))*L.s});
  const ord=Object.values(el).sort((a,b)=>(a.z||0)-(b.z||0));
  const fondo=AZS.filter(q=>q.azione==="folla"&&q.z!=null&&q.z<0);fondo.forEach(q=>AZ.folla(t,sq(q),S,pos,el));
  ord.forEach(e=>{const ps=e.passo||0;const k=EB(ph(t,S.i0+ps,e.f??0.1,(e.f??0.1)+0.6));if(k<=0||e._nascosto||e.nascosto)return;const P=pos(e);if(!P)return;const s=(e.size||160)*e._scala*L.s;
    c.save();c.globalAlpha*=cl(k)*(e._luce<0?1+0.6*e._luce:1);forma({id:e.id,tipo:"oggetto",su:e.su,box:S._box},()=>drawEl(e,P,s,k));c.restore();
    if(e.etichetta){const b=L.bb[e._v];let lx,ly;if(b&&!M){lx=L.dx+L.s*(b.x0+b.x1)/2+(e.dx||0);ly=L.dy+L.s*b.y1+44+(e.dy||0)}else{ly=(String(e.icona).startsWith("persona:")?P[1]+52:P[1]+s*(e.cerchio?0.62:0.55)+40)+(e.dy||0);lx=P[0]+(e.dx||0)}
      const LL=String(e.etichetta).split("\n");const lw=Math.max(...LL.map(l=>tw(l,"600 34px RM")))+36;lx=Math.max(X0+20+lw/2,Math.min(X1-20-lw/2,lx));const pf=FORMA_ID;FORMA_ID=e.id;c.save();c.globalAlpha*=cl(k);rr(lx-lw/2,ly-36,lw,56+(LL.length-1)*44,28);c.fillStyle="rgba(10,15,24,.88)";c.fill();LL.forEach((l,q)=>txt(l,lx,ly+4+q*44,"600 34px RM",COL.bianco,"center"));c.restore();FORMA_ID=pf}});
  AZS.filter(q=>!["cresci","cala","accendi","spegni"].includes(q.azione)&&!fondo.includes(q)).forEach(q=>{const f=AZ[q.azione];if(f)f(t,["folla","attraversa"].includes(q.azione)?sq(q):q,S,pos,el)});
  c.restore();if(p.didascalia){const e=E(ph(t,S.i0+(p.didascalia_passo||0),0.4,0.9));wrap(p.didascalia,"500 28px RM",900).forEach((l,m)=>txt(l,540,Y1+50+m*38,"500 28px RM",COL.grigio,"center",e))}
  c.restore()};
window.cercaIcona=risolvi;

/* ---------- scena «barre»: la corsa verso una soglia (es. 61 seggi) ---------- */
SC.barre=(t,S)=>{const p=S.p,Rw=p.righe||[];let cs=0;for(let j=0;j<S.n;j++)if(t>=at(S.i0+j,-0.1))cs=j;const mx=p.max||Math.max(...Rw.map(r=>r.segmenti.reduce((a,b)=>a+b.v,0)),p.soglia?p.soglia.v*1.15:0);
  const X0=110,X1=980,k=(X1-X0)/mx;const avail=1760-S.top;const rh=Math.min(420,(avail-200)/Rw.length);const y0=S.top+Math.max(110,(avail-rh*Rw.length)/2+40);c.save();c.globalAlpha*=E(ph(t,S.i0,-0.2,0.4));
  Rw.forEach((r,ri)=>{const ra=E(ph(t,S.i0+(r.passo||0),0,0.4));if(ra<=0||cs<(r.passo||0))return;const yb=y0+ri*rh+rh*0.45;c.save();c.globalAlpha*=ra;forma({id:"riga"+ri,tipo:"barra",box:{x0:40,y0:S.top,x1:1040,y1:1880}},()=>{c.save();
    if(r.persona)persona(r.persona,X0+60,yb-130,170,col(r.colore||"azz"),1);txt(r.etichetta||"",X0+(r.persona?130:0),yb-150,"600 52px RS",COL.bianco,"left");
    rr(X0,yb-115,X1-X0,230,18);c.fillStyle="#141f31";c.fill();let x=X0,end=X0;
    r.segmenti.forEach(sg0=>{const sp=sg0.passo||0;if(cs<sp)return;const e=EI(ph(t,S.i0+sp,sg0.f??0.2,(sg0.f??0.2)+1.0));const w=sg0.v*k*e;const cc=col(sg0.colore||r.colore||"azz");
      if(sg0.tenue){c.save();c.beginPath();c.rect(x,yb-115,w,230);c.clip();c.globalAlpha*=0.35;c.strokeStyle=cc;c.lineWidth=4;for(let q=x-230;q<x+w;q+=30){c.beginPath();c.moveTo(q,yb+115);c.lineTo(q+230,yb-115);c.stroke()}c.restore();c.save();c.setLineDash([10,8]);c.strokeStyle=cc;c.lineWidth=3;c.globalAlpha*=0.8;c.strokeRect(x+2,yb-113,w-4,226);c.restore()}
      else if(sg0.tratteggio){c.save();c.beginPath();c.rect(x,yb-115,w,230);c.clip();c.fillStyle=mix("#141f31",cc,0.35);c.fillRect(x,yb-115,w,230);c.strokeStyle=cc;c.lineWidth=6;for(let q=x-180;q<x+w;q+=24){c.beginPath();c.moveTo(q,yb+115);c.lineTo(q+230,yb-115);c.stroke()}c.restore()}
      else{rr(x,yb-115,Math.max(0,w),230,[x===X0?18:0,0,0,x===X0?18:0]);c.fillStyle=cc;c.fill()}
      if(sg0.etichetta&&e>0.9){const xr=p.soglia?X0+p.soglia.v*k-44:Math.min(X1,x+w);String(sg0.etichetta).split("\n").forEach((l,m)=>txt(l,xr,yb+166+m*42,(m?"500 28px RM":"600 30px RM"),m?COL.grigio:cc,"right",E(ph(t,S.i0+sp,1.0,1.4))))}x+=w;end=x});
    const tot=r.segmenti.filter(s0=>cs>=(s0.passo||0)).reduce((a,b)=>a+b.v,0);const vis0=cs>=(r.segmenti[0].passo||0);const vv=r.valore!=null?(vis0?String(r.valore):""):(tot?String(tot):"");const xv=r.valore!=null?X0+r.segmenti[0].v*k*EI(ph(t,S.i0+(r.segmenti[0].passo||0),r.segmenti[0].f??0.2,(r.segmenti[0].f??0.2)+1.0)):end;const c0=col(r.segmenti[0].colore||r.colore||"azz");const lu=c0[0]==="#"?(0.2126*parseInt(c0.slice(1,3),16)+0.7152*parseInt(c0.slice(3,5),16)+0.0722*parseInt(c0.slice(5,7),16))/255:0;if(xv-X0>170)txt(vv,Math.min(xv-20,X1-16),yb+36,"600 100px RS",lu>0.45?"#0c1424":COL.bianco,"right",1);
    if(r.mancano&&cs>=r.mancano.passo){const m=r.mancano,e=E(ph(t,S.i0+m.passo,0.3,0.8));const xa=X0+m.da*k,xb=X0+m.a*k;c.save();c.globalAlpha*=e*(0.6+0.4*Math.sin(t*4));c.setLineDash([10,8]);c.strokeStyle=COL.oro;c.lineWidth=5;c.strokeRect(xa,yb-115,xb-xa,230);c.restore();
      txt(m.etichetta,xb-44,yb+166,"600 40px RM",COL.oro,"right",e)}c.restore()});c.restore()});
  if(p.soglia){const e=E(ph(t,S.i0+(p.soglia.passo||0),0.1,0.6));const xs=X0+p.soglia.v*k;c.save();c.globalAlpha*=e;c.strokeStyle=COL.oro;c.lineWidth=6;c.setLineDash([14,10]);c.beginPath();c.moveTo(xs,y0-40);c.lineTo(xs,y0+rh*Rw.length-20);c.stroke();c.restore();
    txt(p.soglia.etichetta||String(p.soglia.v),xs,y0-58,"600 60px RS",COL.oro,"center",e);if(p.soglia.nota)txt(p.soglia.nota,xs,y0-112,"500 26px RM",COL.oro,"center",e)}
  if(p.nota){const e=E(ph(t,S.i0+(p.nota_passo||0),0.6,1.1));wrap(p.nota,"500 30px RM",880).forEach((l,m)=>txt(l,540,y0+rh*Rw.length+40+m*40,"500 30px RM",COL.grigio,"center",e))}c.restore()};
