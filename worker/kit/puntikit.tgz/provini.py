# provini.py sb.json — provini di voce: le prime frasi del copione lette da più voci Gemini, in un unico video con un cartello per voce.
# Scrive provini.mp4 e stampa un JSON con l'esito di ogni voce.
import sys,os,json,subprocess
HERE=os.path.dirname(os.path.abspath(__file__));F=json.load(open(sys.argv[1],encoding="utf-8"));F=F["frasi_voce"] if isinstance(F,dict) else F
MODEL=os.environ.get("RG_POD_MODEL","gemini-2.5-pro-tts")
TESTO="\n\n".join([F[i] for i in (0,1,2,3,7) if i<len(F)])
ATTUALE=("Leggi in italiano come il narratore di un video divulgativo per i social: voce calda e chiara, ritmo naturale e scorrevole, "
 "mai affrettato, con il tono di chi spiega una cosa importante a un amico. Metti in rilievo i numeri. "
 "Tra un paragrafo e l'altro fai SEMPRE una pausa netta di circa un secondo. Leggi solo il testo, parola per parola, senza aggiungere né togliere nulla.")
VIVA=("Sei un creator italiano che racconta le notizie su TikTok e Instagram a ragazzi che non ne sanno nulla. Leggi in italiano con una voce viva e coinvolgente, "
 "piena di sfumature: cambia ritmo e intonazione da una frase all'altra. Racconta la prima frase come una piccola sorpresa, con un filo di stupore; "
 "la seconda come un colpo di scena; fai la domanda «Chi ha ragione?» come una domanda vera, curiosa, a chi ti ascolta. "
 "Quando arrivano i numeri rallenta un attimo e scandiscili, come chi svela la cosa importante; nelle parti di racconto vai più sciolto. "
 "Sorridi con la voce, senza mai esagerare né sembrare una pubblicità. Tra un paragrafo e l'altro fai SEMPRE una pausa netta di circa un secondo. "
 "Leggi solo il testo, parola per parola, senza aggiungere né togliere nulla.")
PROV=[("Orus","voce attuale, prompt attuale",ATTUALE),("Orus","voce attuale, prompt espressivo",VIVA),("Puck","allegra",VIVA),
      ("Fenrir","energica",VIVA),("Sadachbia","vivace",VIVA),("Laomedeia","femminile, allegra",VIVA)]
open("prov_testo.txt","w",encoding="utf-8").write(TESTO)
os.makedirs("prov",exist_ok=True);esito=[];parti=[]
for n,(voce,desc,pr) in enumerate(PROV,1):
    wav=f"prov/v{n}.wav"
    r=subprocess.run(["python3",os.path.join(HERE,"gem_vertex.py"),voce,MODEL,"prov_testo.txt",wav,pr],capture_output=True,text=True)
    if r.returncode or not os.path.exists(wav): esito.append({"n":n,"voce":voce,"ok":False,"errore":(r.stdout+r.stderr)[-200:]});continue
    png=f"prov/c{n}.png";subprocess.run(["node",os.path.join(HERE,"cartello.mjs"),png,f"PROVINO {n}",voce,desc],check=True)
    mp4=f"prov/p{n}.mp4"
    subprocess.run(["ffmpeg","-y","-v","error","-loop","1","-framerate","30","-i",png,"-i",wav,"-filter_complex","[1:a]aresample=44100,apad=pad_dur=0.8,loudnorm=I=-14:TP=-1.5:LRA=11,aresample=44100[a]",
                    "-map","0:v","-map","[a]","-shortest","-c:v","libx264","-pix_fmt","yuv420p","-crf","28","-c:a","aac","-b:a","128k",mp4],check=True)
    parti.append(mp4);d=float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",wav],capture_output=True,text=True).stdout)
    esito.append({"n":n,"voce":voce,"desc":desc,"ok":True,"secondi":round(d,1)})
if not parti: sys.exit("nessun provino riuscito: "+json.dumps(esito))
open("prov/lista.txt","w").write("".join(f"file '{os.path.basename(p)}'\n" for p in parti))
subprocess.run(["ffmpeg","-y","-v","error","-f","concat","-safe","0","-i","prov/lista.txt","-c","copy","provini.mp4"],check=True)
mb=os.path.getsize("provini.mp4")/1e6
print(json.dumps({"ok":True,"mb":round(mb,2),"provini":esito},ensure_ascii=False))
