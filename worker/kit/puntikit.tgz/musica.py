# musica.py DURATA out.wav [sorgente] — musica originale lunga quanto il video, senza giri corti:
# apertura [0,39) + parti centrali [10,39) quante servono, unite con dissolvenze, e il finale vero [39,45) che cade sulla fine.
import sys,subprocess
L=float(sys.argv[1]);out=sys.argv[2];src=sys.argv[3] if len(sys.argv)>3 else "musica_originale_45s.mp3"
X=1.5;END=6.0;segs=[(0,39)];tot=39
while tot+29-X<L-END+X: segs.append((10,39));tot+=29-X
# accorcia l'ultimo pezzo centrale perché il finale cada esattamente sulla fine
need=L-END+X-tot
if need>0: segs.append((10,10+need+X));tot+=need
segs.append((39,45))
import os
os.makedirs("mseg",exist_ok=True);files=[]
for i,(a,b) in enumerate(segs):
    f=f"mseg/s{i}.wav";subprocess.run(["ffmpeg","-y","-v","error","-ss",str(a),"-to",str(b),"-i",src,f],check=True);files.append(f)
args=["ffmpeg","-y","-v","error"]
for f in files:args+=["-i",f]
fc="";cur="0:a"
for i in range(1,len(files)):
    o=f"x{i}";fc+=f"[{cur}][{i}:a]acrossfade=d={X}:c1=tri:c2=tri[{o}];";cur=o
args+=["-filter_complex",fc.rstrip(";"),"-map",f"[{cur}]","-t",str(L),out] if fc else ["-map","0:a","-t",str(L),out]
subprocess.run(args,check=True)
print("musica",out,L)
