# gem_vertex.py VOCE MODELLO TESTO_FILE OUT.wav PROMPT — Gemini TTS via Agent Platform (Vertex) generateContent, chiave legata al service account
import sys,os,json,base64,urllib.request,wave
voice,model,tf,out,prompt=sys.argv[1:6]
key=os.environ.get("GOOGLE_AGENT_KEY") or open(os.path.join(os.path.dirname(os.path.abspath(__file__)),"sec","key2")).read().strip()
if not key: sys.exit("manca GOOGLE_AGENT_KEY")
text=open(tf).read().strip()
body={"contents":[{"role":"user","parts":[{"text":prompt+"\n\n"+text}]}],
      "generationConfig":{"responseModalities":["AUDIO"],"speechConfig":{"voiceConfig":{"prebuiltVoiceConfig":{"voiceName":voice}}}}}
url=f"https://aiplatform.googleapis.com/v1/publishers/google/models/{model}:generateContent?key={key}"
req=urllib.request.Request(url,data=json.dumps(body).encode(),headers={"content-type":"application/json"})
import time
for tent in range(4):
    try:
        r=json.load(urllib.request.urlopen(req,timeout=300)); break
    except urllib.error.HTTPError as e:
        msg=e.read().decode()[:700]
        if e.code in (429,500,502,503,504) and tent<3: time.sleep(8*(tent+1)); continue
        print(e.code,msg); sys.exit(1)
    except Exception as e:
        if tent<3: time.sleep(8*(tent+1)); continue
        print("errore di rete",e); sys.exit(1)
p=r["candidates"][0]["content"]["parts"][0]["inlineData"]
pcm=base64.b64decode(p["data"]); rate=int(p.get("mimeType","rate=24000").split("rate=")[-1].split(";")[0] or 24000)
w=wave.open(out,"wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(pcm); w.close()
print(out,"ok",p.get("mimeType"))
