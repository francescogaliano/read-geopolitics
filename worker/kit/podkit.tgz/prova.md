# prova
---
**APERTURA**

Buongiorno. Questa è una prova del kit del podcast.

---

**IN SESSANTA SECONDI**

Prima notizia di prova. Seconda notizia di prova.

---

**1 · Prova**

Primo. Una storia di prova, breve, per controllare che tutto funzioni.

---

**L'ITALIA**

**2 · Prova Italia**

E adesso l'Italia. Un'altra frase di prova.

---

**CHIUSURA**

Fine della prova. Ci sentiamo domani.
