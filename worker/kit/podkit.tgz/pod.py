# pod.py COPIONE.md OUT.mp3 [VOCE] — monta la puntata del podcast di Read Geopolitics
# Solo Python di base + ffmpeg (niente numpy/scipy: nell'ambiente dei task non si installano).
# Voce Gemini 2.5 Pro TTS (voce Orus) tramite Agent Platform, chiave in GOOGLE_AGENT_KEY. Un blocco audio per sezione, poi volume e velocità uniformati.
# Musica originale lontana sotto tutta la puntata, stacchi brevi tra le storie, sigla e finale pieni. Uscita mp3 mono 64k, -16 LUFS.
# COPIONE: sezioni separate da una riga "---"; ogni sezione inizia con un titolo in grassetto:
#   **APERTURA** · **IN SESSANTA SECONDI** · **1 · Titolo** (una per storia) · **L'ITALIA** (prima della prima storia italiana, nella stessa sezione) · **CHIUSURA**
#   Righe [tra quadre], titoli **…**, righe che iniziano con # o * non vengono lette.
import sys, os, re, json, hashlib, subprocess, math
from array import array

HERE = os.path.dirname(os.path.abspath(__file__))
md, out = sys.argv[1:3]
VOICE = sys.argv[3] if len(sys.argv) > 3 else "Orus"
# v3 (11/11/2026): VOCE "Francesco" = la voce clonata di Francesco su ElevenLabs (el_tts.py, chiave in ELEVENLABS_API_KEY),
# con le FRASI FISSE registrate una volta sola (cartella frasi/, indice.json) al posto dei segnaposto {{chiave}} del copione.
# Se ElevenLabs non c'è, non ha crediti o fallisce, TUTTA la puntata passa a Gemini (mai due voci nella stessa puntata)
# e i segnaposto vengono letti con il loro testo.
SR = 44100
MODEL = os.environ.get("RG_POD_MODEL", "gemini-2.5-pro-tts")
PROMPT = os.environ.get("RG_POD_PROMPT") or ("Leggi il testo seguente in italiano come il conduttore di un podcast di attualità del mattino. "
          "Voce calda, chiara e calma. Tieni lo STESSO tono, lo STESSO volume e la STESSA velocità dall'inizio alla fine, circa 150 parole al minuto: "
          "questo testo è un pezzo di una puntata più lunga e deve suonare identico agli altri pezzi. Pause brevi tra le frasi, enfasi leggera solo sui numeri e sui nomi. "
          "Niente toni drammatici, niente accelerazioni. Leggi solo il testo, parola per parola, senza aggiungere né togliere nulla.")
work = os.path.join(HERE, "work"); os.makedirs(work, exist_ok=True)

def ff(*args):
    r = subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", *args], capture_output=True, text=True, stdin=subprocess.DEVNULL)
    if r.returncode: sys.exit("ffmpeg non riuscito: " + r.stderr[-500:])

def read_pcm(path):  # qualsiasi audio → array di campioni int16, mono, 44.1 kHz
    raw = os.path.join(work, "tmp.raw"); ff("-i", path, "-f", "s16le", "-ac", "1", "-ar", str(SR), raw)
    a = array("h"); a.frombytes(open(raw, "rb").read()); return a

# ---------- copione ----------
def paras_of(block):
    res = []
    for p in re.split(r"\n\s*\n", block):
        lines = [l.strip() for l in p.strip().split("\n") if l.strip() and not l.strip().startswith(("[", "#", "**", "*"))]
        t = re.sub(r"\[.*?\]", "", " ".join(lines)).strip()
        if t.startswith("B:"): t = t[2:].strip()
        if t: res.append(t)
    return res
plan = []
for b in open(md, encoding="utf-8").read().split("\n---\n"):
    if b.lstrip().startswith("#"): continue
    m = re.search(r"\*\*(.+?)\*\*", b); h = m.group(1).upper() if m else ""
    ps = paras_of(b)
    if "L'ITALIA" in h: plan.append(("stacco", ""))
    if not ps: continue
    kind = "apertura" if "APERTURA" in h else "in60" if "SESSANTA" in h else "chiusura" if "CHIUSURA" in h else "storia"
    plan.append((kind, "\n\n".join(ps)))  # un blocco unico per sezione: intonazione continua
if not any(k == "chiusura" for k, _ in plan) or not any(k == "in60" for k, _ in plan):
    sys.exit("copione incompleto: servono IN SESSANTA SECONDI e CHIUSURA")

# ---------- voce ----------
# Ogni sezione è generata a parte: per uniformare, silenzi tolti ai bordi, stesso volume (loudnorm)
# e stessa velocità (atempo verso la mediana, al massimo ±8%, solo sui pezzi lunghi).
FRASI = os.path.join(HERE, "frasi")
TOK = re.compile(r"\{\{\s*([a-z0-9_]+)\s*\}\}")
# le frasi fisse stanno nel repository (worker/kit/frasi_fisse.tgz), non nel kit del Worker: si scaricano la prima volta
FRASI_URL = os.environ.get("RG_FRASI_URL", "https://raw.githubusercontent.com/francescogaliano/read-geopolitics/main/worker/kit/frasi_fisse.tgz")
if VOICE.lower() == "francesco" and not os.path.exists(os.path.join(FRASI, "indice.json")):
    os.makedirs(FRASI, exist_ok=True); tg = os.path.join(work, "frasi.tgz")
    if subprocess.run(["curl", "-sfL", "-m", "120", FRASI_URL, "-o", tg]).returncode == 0:
        subprocess.run(["tar", "xzf", tg, "-C", FRASI, "--no-same-owner"])
IDX = {}
if os.path.exists(os.path.join(FRASI, "indice.json")):
    for x in json.load(open(os.path.join(FRASI, "indice.json"), encoding="utf-8")):
        if os.path.exists(os.path.join(FRASI, x["file"])): IDX.setdefault(x["chiave"], []).append(x)
    for k in IDX: IDX[k].sort(key=lambda x: (x["variante"], x["take"]))

def tok_text(k):  # testo di una frase fissa, per leggerla con la voce generata
    if k in IDX: return IDX[k][0]["testo"]
    sys.exit("segnaposto sconosciuto nel copione: {{" + k + "}}")

def el_crediti():
    try:
        import urllib.request
        b = os.environ.get("ELEVENLABS_BASE", "https://api.elevenlabs.io")
        r = json.load(urllib.request.urlopen(urllib.request.Request(b + "/v1/user/subscription", headers={"xi-api-key": os.environ["ELEVENLABS_API_KEY"].strip()}), timeout=30))
        return r["character_limit"] - r["character_count"]
    except Exception as e:
        return None

ENGINE, MOTIVO = "gemini", ""
if VOICE.lower() == "francesco":
    tot = sum(len(TOK.sub("", t)) for k, t in plan)
    if not os.environ.get("ELEVENLABS_API_KEY"): MOTIVO = "manca ELEVENLABS_API_KEY"
    elif not IDX: MOTIVO = "mancano le frasi fisse (cartella frasi/)"
    else:
        cr = el_crediti()
        if cr is None: MOTIVO = "crediti ElevenLabs non leggibili"
        elif cr < tot + 1500: MOTIVO = f"crediti ElevenLabs insufficienti ({cr} rimasti, servono fino a {tot + 1500})"
        else: ENGINE = "elevenlabs"
    if ENGINE == "gemini": print("ATTENZIONE: voce Gemini al posto della voce di Francesco: " + MOTIVO, file=sys.stderr)
GVOICE = VOICE if VOICE.lower() != "francesco" else "Orus"

def tts(text, engine):
    tag = "el|CBomCrEu5ntWbrwkEBIm|eleven_v4" if engine == "elevenlabs" else MODEL + "|" + GVOICE + "|" + PROMPT
    hsh = hashlib.sha1((tag + "|" + text).encode()).hexdigest()[:16]
    wav = os.path.join(work, hsh + "_g.wav")
    if not os.path.exists(wav):
        tf = os.path.join(work, hsh + ".txt"); open(tf, "w").write(text)
        cmd = ["python3", os.path.join(HERE, "el_tts.py"), tf, wav] if engine == "elevenlabs" else ["python3", os.path.join(HERE, "gem_vertex.py"), GVOICE, MODEL, tf, wav, PROMPT]
        r = subprocess.run(cmd, capture_output=True, text=True, stdin=subprocess.DEVNULL)
        if r.returncode or not os.path.exists(wav): raise RuntimeError("TTS non riuscito (" + engine + "): " + (r.stdout + r.stderr)[-600:])
    return wav

TRIM = "silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.05,areverse,silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.05,areverse"
def uniforma(src, tempo):
    nw = os.path.join(work, hashlib.sha1(src.encode()).hexdigest()[:12] + "_n%.3f.wav" % tempo)
    af = TRIM + (",atempo=%.4f" % tempo if abs(tempo - 1) > 0.005 else "") + ",loudnorm=I=-18:TP=-2:LRA=7"
    if not os.path.exists(nw): ff("-i", src, "-af", af, "-ar", str(SR), "-ac", "1", nw)
    return read_pcm(nw)

USO = {}
def clip(k):  # sceglie la frase fissa a rotazione tra varianti e registrazioni, diversa ogni giorno
    L = IDX[k]; n = USO.get(k, 0); USO[k] = n + 1
    seed = int(hashlib.sha1(os.path.basename(md).encode()).hexdigest()[:6], 16)
    return os.path.join(FRASI, L[(seed + n) % len(L)]["file"])

def pezzi(text, engine):  # una sezione → lista di ("tts", testo) e ("clip", file), nell'ordine
    out = []
    if engine != "elevenlabs":
        t = TOK.sub(lambda m: tok_text(m.group(1)), text); return [("tts", t)]
    pos = 0
    for m in TOK.finditer(text):
        pre = text[pos:m.start()].strip()
        if pre: out.append(("tts", pre))
        tok_text(m.group(1)); out.append(("clip", clip(m.group(1)))); pos = m.end()
    rest = text[pos:].strip()
    if rest: out.append(("tts", rest))
    return out

def genera(engine):
    global USO; USO = {}
    secs = []
    for kind, text in plan:
        if kind == "stacco": secs.append((kind, text, [])); continue
        secs.append((kind, text, [(tp, tts(x, engine) if tp == "tts" else x, x) for tp, x in pezzi(text, engine)]))
    return secs
try:
    secs = genera(ENGINE)
except RuntimeError as e:
    if ENGINE != "elevenlabs": sys.exit(str(e))
    MOTIVO = "ElevenLabs ha dato errore a metà: " + str(e)[:200]; print("ATTENZIONE: rifaccio tutta la puntata con Gemini: " + MOTIVO, file=sys.stderr)
    ENGINE = "gemini"; secs = genera(ENGINE)

# velocità di lettura dei pezzi generati lunghi (caratteri al secondo, senza i silenzi ai bordi) e mediana
rates = {}
for kind, text, ps in secs:
    for tp, f, x in ps:
        if tp == "tts" and len(x) >= 200: rates[f] = len(x) / max(1.0, len(uniforma(f, 1.0)) / SR)
med = sorted(rates.values())[len(rates) // 2] if rates else 15.0

parts, t, nchar, stings, prev, nclip = [], 5.0, 0, [], None, 0
for kind, text, ps in secs:
    if kind == "stacco":
        stings.append(t + 0.4); t += 3.4; prev = "stacco"; continue
    if kind == "storia" and prev in ("storia", "in60"):
        stings.append(t + 0.5); t += 3.0
    if kind == "chiusura": t += 1.0; cs = t
    for j, (tp, f, x) in enumerate(ps):
        if tp == "tts":
            tempo = min(1.08, max(0.92, med / rates[f])) if f in rates else 1.0
            a = uniforma(f, tempo); nchar += len(x)
        else:
            a = uniforma(f, 1.0); nclip += 1
        parts.append((t, a)); t += len(a) / SR + (0.6 if j == len(ps) - 1 else 0.38)
    if kind == "in60": e60 = t
    if kind == "chiusura": ce = t - 0.6
    prev = kind
END = 15 + 4 * math.ceil((ce + 6.0 - 15) / 4)  # lunghezza del brano esteso: il finale vero cade sulla fine
N = int(END * SR)
V = array("h", bytes(2 * N))
for s, a in parts:
    i = int(s * SR); n = min(len(a), N - i)
    V[i:i + n] = a[:n]
open(os.path.join(work, "voce.raw"), "wb").write(V.tobytes())

# ---------- musica: intro [0,10) + groove [6,10) ripetuto + finale [10,15), dissolvenze di 60 ms ----------
src = read_pcm(os.path.join(HERE, "musica_originale_15s.mp3"))
S = lambda a, b: src[int(a * SR):int(b * SR)]
k = max(0, round((END - 15) / 4))
cf = int(0.06 * SR)
# ogni pezzo dopo il primo parte 60 ms prima: la dissolvenza si sovrappone e la durata totale resta esatta
P = lambda a, b: src[int(a * SR) - cf:int(b * SR)]
segs = [S(0, 10)] + [P(6, 10)] * k + [P(10, 15)]
M = array("h", segs[0])
for sg in segs[1:]:
    tail = len(M) - cf
    for j in range(cf):  # dissolvenza incrociata
        w = j / cf
        M[tail + j] = int(M[tail + j] * (1 - w) + sg[j] * w)
    M.extend(sg[cf:])
if len(M) < N: M.extend(array("h", bytes(2 * (N - len(M)))))
M = M[:N]
open(os.path.join(work, "musica.raw"), "wb").write(M.tobytes())

# ---------- curve del volume della musica (100 punti al secondo) ----------
pts = [(0, 1.0), (4.4, 1.0), (5.4, 0.10), (e60 - 0.3, 0.10), (e60 + 0.4, 0.06)]
for s in stings: pts += [(s - 0.4, 0.06), (s + 0.2, 0.42), (s + 1.8, 0.42), (s + 2.6, 0.06)]
pts += [(cs - 0.5, 0.06), (cs + 0.5, 0.10), (ce, 0.10), (ce + 0.8, 0.9), (END - 1.5, 0.9), (END, 0.0)]
pts.sort()
ER = 100
def gain_at(x):
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if x0 <= x <= x1: return y0 if x1 == x0 else y0 + (y1 - y0) * (x - x0) / (x1 - x0)
    return pts[-1][1]
near, far = array("f"), array("f")
for i in range(int(END * ER) + ER):
    g = gain_at(i / ER); w = min(1.0, max(0.0, (g - 0.12) / 0.3))  # 1 = piena (sigla, stacchi, finale), 0 = lontana
    near.append(g * w * 0.6); far.append(g * (1 - w) * 1.25 * 0.6)
open(os.path.join(work, "near.raw"), "wb").write(near.tobytes())
open(os.path.join(work, "far.raw"), "wb").write(far.tobytes())

# ---------- miscelazione con ffmpeg ----------
raw = lambda f, fmt, sr: ["-f", fmt, "-ar", str(sr), "-ac", "1", "-i", os.path.join(work, f)]
mixed = os.path.join(work, "mix.wav")
ff(*raw("voce.raw", "s16le", SR), *raw("musica.raw", "s16le", SR), *raw("near.raw", "f32le", ER), *raw("far.raw", "f32le", ER),
   "-filter_complex",
   "[1]asplit[m1][m2];[m2]lowpass=f=1600,aecho=0.8:0.6:60|120:0.25|0.15[mf];"
   f"[2]aresample={SR}[g1];[3]aresample={SR}[g2];[m1][g1]amultiply[a];[mf][g2]amultiply[b];"
   "[0][a][b]amix=inputs=3:normalize=0:duration=first[x]",
   "-map", "[x]", "-t", f"{END:.2f}", mixed)
ff("-i", mixed, "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "44100", "-ac", "1", "-b:a", "64k", out)
d = END
print(json.dumps({"file": out, "voce": VOICE, "motore": ENGINE, "modello": ("eleven_v4" if ENGINE == "elevenlabs" else MODEL), "ripiego": MOTIVO or None, "frasi_fisse": nclip, "durata": f"{int(d // 60)}:{int(d % 60):02d}", "secondi": round(d), "caratteri": nchar, "stacchi": len(stings), "velocita": {"mediana_car_s": round(med, 2), "min": round(min(rates.values() or [med]), 2), "max": round(max(rates.values() or [med]), 2)}}, ensure_ascii=False))
