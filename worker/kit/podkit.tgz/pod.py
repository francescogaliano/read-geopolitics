# pod.py COPIONE.md OUT.mp3 [VOCE] — monta la puntata del podcast di Read Geopolitics
# Solo Python di base + ffmpeg (niente numpy/scipy: nell'ambiente dei task non si installano).
# Voce Gemini 2.5 Pro TTS (voce Orus) tramite Agent Platform, chiave in GOOGLE_AGENT_KEY. Un blocco audio per sezione.
# Musica originale lontana sotto tutta la puntata, stacchi brevi tra le storie, sigla e finale pieni. Uscita mp3 mono 64k, -16 LUFS.
# COPIONE: sezioni separate da una riga "---"; ogni sezione inizia con un titolo in grassetto:
#   **APERTURA** · **IN SESSANTA SECONDI** · **1 · Titolo** (una per storia) · **L'ITALIA** (prima della prima storia italiana, nella stessa sezione) · **CHIUSURA**
#   Righe [tra quadre], titoli **…**, righe che iniziano con # o * non vengono lette.
import sys, os, re, json, hashlib, subprocess, math
from array import array

HERE = os.path.dirname(os.path.abspath(__file__))
md, out = sys.argv[1:3]
VOICE = sys.argv[3] if len(sys.argv) > 3 else "Orus"
SR = 44100
MODEL = os.environ.get("RG_POD_MODEL", "gemini-2.5-pro-tts")
PROMPT = os.environ.get("RG_POD_PROMPT") or ("Leggi il testo seguente in italiano come il conduttore di un podcast di attualità internazionale del mattino: "
          "tono caldo, chiaro e coinvolgente, come un giornalista radio esperto che racconta a un amico. Ritmo naturale, pause dove servono, "
          "enfasi sulle parole chiave, mai monotono. Leggi solo il testo, parola per parola, senza aggiungere né togliere nulla.")
work = os.path.join(HERE, "work"); os.makedirs(work, exist_ok=True)

def ff(*args):
    r = subprocess.run(["ffmpeg", "-loglevel", "error", "-y", *args], capture_output=True, text=True)
    if r.returncode: sys.exit("ffmpeg non riuscito: " + r.stderr[-500:])

def read_pcm(path):  # qualsiasi audio → array di campioni int16, mono, 44.1 kHz
    raw = os.path.join(work, "tmp.raw"); ff("-i", path, "-f", "s16le", "-ac", "1", "-ar", str(SR), raw)
    a = array("h"); a.frombytes(open(raw, "rb").read()); return a

# ---------- copione ----------
def paras_of(block):
    res = []
    for p in re.split(r"\n\s*\n", block):
        lines = [l.strip() for l in p.strip().split("\n") if l.strip() and not l.strip().startswith(("[", "#", "**", "*"))]
        t = re.sub(r"\[.*?\]", "", " ".join(lines)).strip()
        if t.startswith("B:"): t = t[2:].strip()
        if t: res.append(t)
    return res
plan = []
for b in open(md, encoding="utf-8").read().split("\n---\n"):
    if b.lstrip().startswith("#"): continue
    m = re.search(r"\*\*(.+?)\*\*", b); h = m.group(1).upper() if m else ""
    ps = paras_of(b)
    if "L'ITALIA" in h: plan.append(("stacco", ""))
    if not ps: continue
    kind = "apertura" if "APERTURA" in h else "in60" if "SESSANTA" in h else "chiusura" if "CHIUSURA" in h else "storia"
    plan.append((kind, "\n\n".join(ps)))  # un blocco unico per sezione: intonazione continua
if not any(k == "chiusura" for k, _ in plan) or not any(k == "in60" for k, _ in plan):
    sys.exit("copione incompleto: servono IN SESSANTA SECONDI e CHIUSURA")

# ---------- voce ----------
def tts(text):
    hsh = hashlib.sha1((MODEL + "|" + VOICE + "|" + PROMPT + "|" + text).encode()).hexdigest()[:16]
    wav = os.path.join(work, hsh + "_g.wav")
    if not os.path.exists(wav):
        tf = os.path.join(work, hsh + ".txt"); open(tf, "w").write(text)
        r = subprocess.run(["python3", os.path.join(HERE, "gem_vertex.py"), VOICE, MODEL, tf, wav, PROMPT], capture_output=True, text=True)
        if r.returncode or not os.path.exists(wav): sys.exit("TTS non riuscito: " + (r.stdout + r.stderr)[-600:])
    return read_pcm(wav)

parts, t, nchar, stings, prev = [], 5.0, 0, [], None
for kind, text in plan:
    if kind == "stacco":
        stings.append(t + 0.4); t += 3.4; prev = "stacco"; continue
    if kind == "storia" and prev in ("storia", "in60"):
        stings.append(t + 0.5); t += 3.0
    if kind == "chiusura": t += 1.0; cs = t
    a = tts(text); nchar += len(text)
    parts.append((t, a)); t += len(a) / SR + 0.6
    if kind == "in60": e60 = t
    if kind == "chiusura": ce = t - 0.6
    prev = kind
END = 15 + 4 * math.ceil((ce + 6.0 - 15) / 4)  # lunghezza del brano esteso: il finale vero cade sulla fine
N = int(END * SR)
V = array("h", bytes(2 * N))
for s, a in parts:
    i = int(s * SR); n = min(len(a), N - i)
    V[i:i + n] = a[:n]
open(os.path.join(work, "voce.raw"), "wb").write(V.tobytes())

# ---------- musica: intro [0,10) + groove [6,10) ripetuto + finale [10,15), dissolvenze di 60 ms ----------
src = read_pcm(os.path.join(HERE, "musica_originale_15s.mp3"))
S = lambda a, b: src[int(a * SR):int(b * SR)]
k = max(0, round((END - 15) / 4))
cf = int(0.06 * SR)
# ogni pezzo dopo il primo parte 60 ms prima: la dissolvenza si sovrappone e la durata totale resta esatta
P = lambda a, b: src[int(a * SR) - cf:int(b * SR)]
segs = [S(0, 10)] + [P(6, 10)] * k + [P(10, 15)]
M = array("h", segs[0])
for sg in segs[1:]:
    tail = len(M) - cf
    for j in range(cf):  # dissolvenza incrociata
        w = j / cf
        M[tail + j] = int(M[tail + j] * (1 - w) + sg[j] * w)
    M.extend(sg[cf:])
if len(M) < N: M.extend(array("h", bytes(2 * (N - len(M)))))
M = M[:N]
open(os.path.join(work, "musica.raw"), "wb").write(M.tobytes())

# ---------- curve del volume della musica (100 punti al secondo) ----------
pts = [(0, 1.0), (4.4, 1.0), (5.4, 0.10), (e60 - 0.3, 0.10), (e60 + 0.4, 0.06)]
for s in stings: pts += [(s - 0.4, 0.06), (s + 0.2, 0.42), (s + 1.8, 0.42), (s + 2.6, 0.06)]
pts += [(cs - 0.5, 0.06), (cs + 0.5, 0.10), (ce, 0.10), (ce + 0.8, 0.9), (END - 1.5, 0.9), (END, 0.0)]
pts.sort()
ER = 100
def gain_at(x):
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if x0 <= x <= x1: return y0 if x1 == x0 else y0 + (y1 - y0) * (x - x0) / (x1 - x0)
    return pts[-1][1]
near, far = array("f"), array("f")
for i in range(int(END * ER) + ER):
    g = gain_at(i / ER); w = min(1.0, max(0.0, (g - 0.12) / 0.3))  # 1 = piena (sigla, stacchi, finale), 0 = lontana
    near.append(g * w * 0.6); far.append(g * (1 - w) * 1.25 * 0.6)
open(os.path.join(work, "near.raw"), "wb").write(near.tobytes())
open(os.path.join(work, "far.raw"), "wb").write(far.tobytes())

# ---------- miscelazione con ffmpeg ----------
raw = lambda f, fmt, sr: ["-f", fmt, "-ar", str(sr), "-ac", "1", "-i", os.path.join(work, f)]
mixed = os.path.join(work, "mix.wav")
ff(*raw("voce.raw", "s16le", SR), *raw("musica.raw", "s16le", SR), *raw("near.raw", "f32le", ER), *raw("far.raw", "f32le", ER),
   "-filter_complex",
   "[1]asplit[m1][m2];[m2]lowpass=f=1600,aecho=0.8:0.6:60|120:0.25|0.15[mf];"
   f"[2]aresample={SR}[g1];[3]aresample={SR}[g2];[m1][g1]amultiply[a];[mf][g2]amultiply[b];"
   "[0][a][b]amix=inputs=3:normalize=0:duration=first[x]",
   "-map", "[x]", "-t", f"{END:.2f}", mixed)
ff("-i", mixed, "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "44100", "-ac", "1", "-b:a", "64k", out)
d = END
print(json.dumps({"file": out, "voce": VOICE, "modello": MODEL, "durata": f"{int(d // 60)}:{int(d % 60):02d}", "secondi": round(d), "caratteri": nchar, "stacchi": len(stings)}, ensure_ascii=False))
