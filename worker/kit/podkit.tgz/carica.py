# carica.py PUNTATA.mp3 AAAA-MM-GG "TITOLO" "DESCRIZIONE" SECONDI [TEMI.json] — carica la puntata sul Worker (RG_API, RG_TOKEN)
import sys,os,json,urllib.request
mp3,date,title,desc,sec=sys.argv[1:6]
temi=None
if len(sys.argv)>6:
    temi=json.load(open(sys.argv[6],encoding="utf-8"))  # {"mondo":[..],"italia":[..],"mondo_brevi":[..],"italia_brevi":[..]}: servono alla storia Instagram del pannello
api=os.environ["RG_API"].rstrip("/"); tok=os.environ["RG_TOKEN"]
H={"authorization":"Bearer "+tok,"user-agent":"rg-routine/1.0"}
def call(method,path,data,ctype):
    for t in range(3):
        try:
            req=urllib.request.Request(api+path,data=data,method=method,headers={**H,"content-type":ctype})
            return json.loads(urllib.request.urlopen(req,timeout=300).read().decode())
        except urllib.error.HTTPError as e:
            body=e.read().decode()[:400]
            if e.code<500 or t==2: sys.exit(f"{method} {path}: {e.code} {body}")
        except Exception as e:
            if t==2: sys.exit(f"{method} {path}: {e}")
r1=call("PUT",f"/v1/podcast/audio/{date}.mp3",open(mp3,"rb").read(),"audio/mpeg"); print("audio",r1)
r2=call("POST","/v1/podcast/episodes",json.dumps({"date":date,"title":title,"description":desc,"duration":int(float(sec)),**({"chapters":temi} if temi else {})}).encode(),"application/json"); print("puntata",r2)
