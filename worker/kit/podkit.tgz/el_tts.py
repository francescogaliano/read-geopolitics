# el_tts.py TESTO.txt OUT.wav — voce clonata di Francesco su ElevenLabs (eleven_v4_turbo, o RG_EL_MODEL), chiave in ELEVENLABS_API_KEY.
import sys,os,json,urllib.request,urllib.error,subprocess,time
tf,wav=sys.argv[1:3];txt=open(tf,encoding="utf-8").read()
key=os.environ["ELEVENLABS_API_KEY"].strip();vid=os.environ.get("ELEVENLABS_VOICE_ID","").strip() or "CBomCrEu5ntWbrwkEBIm"
base=os.environ.get("ELEVENLABS_BASE","https://api.elevenlabs.io")
MODELLO=os.environ.get("RG_EL_MODEL","").strip() or "eleven_v4_turbo"  # dal 12/11/2026: v4 Turbo, metà crediti di eleven_v4 (prova su una puntata intera)
body={"text":txt,"model_id":MODELLO,"language_code":"it","voice_settings":{"stability":0.5,"similarity_boost":0.9}}
req=urllib.request.Request(base+f"/v1/text-to-speech/{vid}?output_format=mp3_44100_128",data=json.dumps(body).encode(),
      headers={"xi-api-key":key,"content-type":"application/json","accept":"audio/mpeg"})
for t in range(3):
    try: data=urllib.request.urlopen(req,timeout=300).read();break
    except urllib.error.HTTPError as e:
        m=e.read().decode()[:300]
        if e.code in (429,500,502,503,504) and t<2: time.sleep(15*(t+1));continue
        sys.exit(f"ElevenLabs {e.code}: {m}")
    except Exception as e:
        if t<2: time.sleep(15*(t+1));continue
        sys.exit(f"ElevenLabs: {e}")
mp3=wav[:-4]+".mp3";open(mp3,"wb").write(data)
subprocess.run(["ffmpeg","-nostdin","-loglevel","error","-y","-i",mp3,"-ar","44100","-ac","1",wav],check=True)
